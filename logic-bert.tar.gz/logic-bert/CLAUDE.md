# CLAUDE.md — logic-bert

Standalone C11 **differentiable logic gate network** (DDLGN / "LogicText") for text,
being scaled toward a **BERT-style pretrain → fine-tune** comparison against BERT-Tiny.
Read this file fully, then `RESULTS.md` (what is known) and `TASKS.md` (what to do).

## What the model is (30-second version)
- Word-level vocab (default 8,192; IDs 0=PAD 1=MASK 2=UNK). Each word → learned **64-bit code**
  (sigmoid-relaxed in training, hard bits at inference). NOT bytes/subwords.
- 8 conv blocks of **depth-3 binary gate trees** (8 leaves, 7 two-input gates each, each gate a
  learned 4-entry truth table). Dilations 1,2,…,128 cycle. Wiring (channel + offset per leaf)
  is **fixed random at init** — only truth tables and codes are learned.
- Pair max-pool (OR at inference) → head gate trees → integer **votes** per class (2 classes).
- MLM path (`pretrain`): depth-2 projection + decoder tied to the word codes (Hamming-style
  dot product over all V words) + per-word bias. Training-only.
- Deployed `.lth` model is float-free: packed uint64 bit ops + integer vote counting.

## Layout
```
src/logic_text.c           THE build. Lane-major vectorized + deterministic OpenMP.
reference/logic_text_ref.c Original serial implementation (functional copy; header/usage
                           text abbreviated). Ground truth for bitwise tests. Do not edit.
tools/  soft.c (soft vs hard acc)  ens.c (vote-sum ensembles)  prof.c (fwd/bwd/adam split)
        micro.c (fp32/fp16/lane microbenchmark). Harnesses #include "logic_text.c" (-Isrc).
scripts/ prep_imdb.py  determinism.sh  stage1.sh  lexical_ablation.py
models/  imdb_baseline_k3.lth, imdb_kernel5.lth  (trained, see RESULTS.md)
data/    created by `make data` (not shipped)
```

## Commands
```
make all          # bin/lt (src) and bin/lt_ref (reference)
make data         # reproduce IMDB splits + vocab (needs pandas, openpyxl, curl)
make check        # selftest + bitwise determinism gate  <-- run after ANY C change
make tools        # bin/soft bin/ens bin/prof bin/micro
bin/lt --help     # CLI; train/pretrain/eval/predict/bench/export/info/vocab
```
Typical run (the current best config):
```
bin/lt train --data data/imdb/train.tsv --val data/imdb/val.tsv --format tsv \
  --vocab data/imdb/vocab.txt --kernel 5 --steps 6000 --seed 17 --eval-every 500 \
  --save runs/k5.ltc --export runs/k5.lth --threads $(nproc) --batch 16
bin/lt eval --load runs/k5.lth --data data/imdb/val.tsv --format tsv --seq 512 --batch 64
```

## Invariants — do not break these
1. **Bitwise determinism.** `src` must produce checkpoints byte-identical to `reference` at any
   thread count (`make check`). Every refactor so far preserved this; it is the main defense
   against silent gradient bugs. If you intentionally change numerics (new features, new
   layers, fp16, etc.), say so explicitly, keep the old path testable, and re-baseline.
2. **Accumulation order.** Determinism holds because each value is accumulated in the same
   order as the serial code. Parallelize over *owners of outputs* (lane chunks, vocab rows,
   targets), never with atomics or unordered reductions.
3. **Lane-major training tensors.** Float activations/gradients in `src` are
   `X[((size_t)t*C + c)*B + b]` (batch innermost, LANES=16). `partial` is `partial[k*B + b]`.
   `valid`, `ids`, `labels`, `pv` keep the original `[b*T + t]` layout.
4. **Checkpoint formats** `LTCKP001` (.ltc: params + Adam + RNG + schedule) and `LTHRD001`
   (.lth: hard model). Any format change must bump the magic (e.g. `LTCKP002`) and keep
   loading the old one or fail loudly.
5. `selftest` finite-difference tolerances (rel 0.035, abs 2e-4) are a gradient contract.
   Do not loosen them to make a change pass.

## Evaluation hygiene (hard-won)
- **Never use the laxmimerit mirror's `test.xlsx`**: all 25,000 of its reviews are in train
  (it produced a fake 90% "test" accuracy once). `prep_imdb.py` builds `test_clean.tsv`
  (24,681 reviews) = 50k corpus minus train/val, deduped.
- Select configs on `val.tsv` only. Touch `test_clean.tsv` once per finished config.
- Report **final-step** metrics as primary; "best seen on val" only as secondary.
- `val.tsv` is 2,500 reviews → ±0.7 pts noise (SST-2 dev, 872 → ±1.4). Differences under
  ~1 pt are not findings without extra seeds.
- Always report accuracy at both `--seq 128` (training window) and `--seq 512`.
  Evaluating longer than trained helps this model (+3.5 pts); a linear model at 128 tokens
  loses 6 pts, so truncation is a first-order effect.
- The per-step `ce` in training logs is a single 16-example batch: noise, not fit.
  Measure fit with `bin/soft MODEL.ltc data/imdb/train.tsv 128` style evals.

## Performance facts
- Backward ≈ 70–76% of step time. Scalar-compute-bound (~2.6 GFLOP/s original), not
  bandwidth-bound; working set fits in L3.
- Lane-major vectorization: step 233 → 104 ms (batch 16), 893 → 443 ms (batch 64), 1 core.
- **fp16 is a trap here**: scalar fp16 math measured 0.80× fp32 (tools/micro.c). Adam
  `eps=1e-8` and `0.001*g²` underflow fp16. Only possible win: fp16 *storage* of activations
  in 32-lane layout with fp32 math/accumulation. Master weights + Adam stay fp32.
- Backward parallelism = batch/16 lane chunks → use **batch ≥ 16 × threads** on big machines.
- MLM decoder cost ∝ targets × V × bits; use `--mlm-targets` to cap positions (never vocab).

## Working style expected by the owner
- The owner rents CPU boxes (~$1/hr) and runs commands you give as a "dumb pipe":
  give copy-paste step blocks, keep long runs under `nohup`, make scripts resumable
  (`--resume` is bitwise exact), write summaries to a file they can paste back.
- Measure before optimizing; verify claims with a test; state uncertainty plainly.
