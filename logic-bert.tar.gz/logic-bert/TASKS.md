# TASKS.md — prioritized queue with acceptance criteria

Status legend: [ ] todo · [~] in progress elsewhere · [x] done

## Goal
Stage 1: validate that Logic-BERT pretraining transfers (small, cheap).
Stage 2: BERT-Tiny-scale pretraining, then GLUE, to see whether a DDLGN can approach
BERT-Tiny (SST-2 83.2, MNLI-m 70.2, QNLI 81.5, RTE 57.2; see RESULTS.md §4).

---

## T0 [~] Stage 1 run (owner runs `scripts/stage1.sh` on a rented many-core box)
Pretrain MLM on WikiText-2 (64M tokens, kernel 5), fine-tune SST-2 six ways
(scratch / pretrained lr .025 / pretrained lr .005 × seeds 17, 23), final-step dev accuracy.
Gates for proceeding to Stage 2:
- **G1** selftest passes; 1 vs N threads bitwise identical (script aborts otherwise).
- **G2** all-core tokens/s ≥ 0.4 × cores × single-thread tokens/s.
- **G3** final `val_mlm_ce` ≤ ~6.1 (≥0.3 nats under the 6.393 unigram baseline). The
  per-word bias alone can reach unigram; beating it proves context use. Biggest risk:
  the 64-bit tied Hamming decoder may be too weak to express context.
- **G4** mean pretrained SST-2 dev ≥ scratch + 2.5 pts (per-run noise ±1.4).
If G3 fails: investigate decoder capacity (more code bits, untied output codes) before
spending on Stage 2.

## T1 [ ] Vocab 32k run on IMDB (zero code changes)
`bin/lt vocab ... --vocab-size 32768`, then the kernel-5 config (6000 steps, seed 17).
Accept: report val@128/@512, fit, and test_clean@512 once. Linear-model upper bound for
this change is ~+1 pt. Compare against kernel-5 86.84 val@512.

## T2 [ ] Hashed word-bigram input channel (biggest measured lexical upside)
Spec:
- Bigram bucket for position t: `h = hash(id[t-1], id[t]) mod H` (H = 2^16 default; t=0 or
  PAD neighbor → a fixed "no-bigram" bucket or zero code). Hash must be integer-only and
  identical in training and hard inference.
- Separate trainable table `bg` (H × bits_bg, same sigmoid/temperature treatment as `emb`,
  same balance/sharpness regularizer or a documented variant).
- Block-0 input channels become `bits + bits_bg` (concatenate). Block 0's `C` changes;
  nothing else in the trunk changes.
- Gradients: scatter block-0 input grads into `emb` rows (as now) and `bg` rows.
- Hard path: pack bigram codes exactly like word codes (`hard_predict` lookup/pack stage).
- New formats `LTCKP002` / `LTHRD002`; old files must still load (bg disabled).
- Extend `selftest`: finite-difference coverage of `bg`; packed-vs-scalar check with
  bigrams; checkpoint roundtrip.
- `make check` must still pass **with bigrams disabled** (bitwise vs reference).
Accept: IMDB kernel-5 + bigram, 6000 steps, seed 17: report val@128/@512 vs 86.84.
Linear evidence: +1.4 val / +2.8 test for bag-of-words.
Do NOT add char 3–6-grams (measured negative on IMDB; revisit only if Stage 2 UNK rates
are high).

## T3 [ ] K-class output (needed for MNLI 3-way, AG News, etc.)
`supervised()` hardcodes `double sum[2]`; `hard_predict` writes `scores[b*2+cls]`;
`eval_hard` does 2-way argmax; head has `2*votes` outputs. Generalize to `classes` K
(config field; default 2 keeps formats identical), softmax CE over K vote sums.
Accept: `make check` passes at K=2 (bitwise); selftest adds K=3 finite-difference and
packed-vs-scalar checks.

## T4 [ ] Sentence-pair input for GLUE (QNLI, QQP, MRPC, RTE, MNLI) — no C changes
Tokenize externally, emit `--format ids` lines: `label id… SEP id…`, reserving one
`[UNUSED_n]` vocab slot as `[SEP]`. Build a small Python converter + GLUE downloader
(HF `datasets` on the rented box). CoLA: binary, report MCC computed from `predict`
output (the CLI only prints accuracy).

## T5 [ ] Tokenization for Stage 2
Word-level 8k vocab will have high UNK on Wikipedia. Train an 8k WordPiece (HF
`tokenizers`) on the pretraining corpus, emit IDS. Keep V ≈ 8k: MLM decoder cost ∝ V.
Measure UNK/OOV rate and tokens/word before and after.

## T6 [ ] Stage 2 token-budget ladder
Corpus: WikiText-103 first (~100M tokens), larger later. Ladder 0.1B → 0.5B → 2B tokens,
evaluating SST-2 (GLUE 67k train, 872 dev) at each rung → scaling curve, not one bet.
Budget from Stage 1's measured tokens/s. Batch ≥ 16 × threads.

## Parked / optional
- 16-block 12k run was parked at step 7000 (checkpoint not shipped). Provisional
  conclusion: depth does not help this architecture. Low priority.
- Kernel 7; kernel 5 + `--cycle 4` (reach is the one lever that worked).
- Readout: linear bag-of-unigrams beats the net at identical info (88.8 vs 86.8). Ideas:
  learned per-vote weights at train time that harden to integer multiplicities; more votes.
- fp16 activation *storage* in a 32-lane layout (fp32 math). Only after profiling says
  the lane kernels are bandwidth-bound.
