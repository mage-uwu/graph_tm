/* micro.c: is the gate-tree backward scalar-compute-bound or bandwidth-bound?
 * Reproduces the per-(b,o,t) inner math of backward_layer four ways. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#define N 7          /* interior gates, depth 3 */
#define R 8          /* leaves */
#define B 16         /* batch lanes */
#define REP 400
static double now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return t.tv_sec+1e-9*t.tv_nsec;}

/* A: scalar fp32, one (b,o,t) at a time -- what the code does now */
static float scalar32(const float *x,const float *p,int iters,float *acc){
    float s=0;
    for(int it=0;it<iters;it++){
        float v[2*R-1],g[2*R-1]={0};
        for(int k=0;k<R;k++)v[N+k]=x[(it*R+k)&1023];
        for(int j=N-1;j>=0;j--){const float*q=p+4*j;float a=v[2*j+1],b=v[2*j+2];
            v[j]=(1-a)*((1-b)*q[0]+b*q[1])+a*((1-b)*q[2]+b*q[3]);}
        g[0]=1.f;
        for(int j=0;j<N;j++){float a=v[2*j+1],b=v[2*j+2],u=g[j];const float*q=p+4*j;
            acc[4*j]+=u*(1-a)*(1-b);acc[4*j+1]+=u*(1-a)*b;acc[4*j+2]+=u*a*(1-b);acc[4*j+3]+=u*a*b;
            g[2*j+1]=u*((1-b)*(q[2]-q[0])+b*(q[3]-q[1]));
            g[2*j+2]=u*((1-a)*(q[1]-q[0])+a*(q[3]-q[2]));}
        for(int k=0;k<R;k++)s+=g[N+k];
    }return s;
}
/* B: scalar fp16 arithmetic (native on avx512_fp16) */
#if defined(__AVX512FP16__)
typedef _Float16 h16;
static float scalar16(const h16 *x,const h16 *p,int iters,h16 *acc){
    h16 s=0;
    for(int it=0;it<iters;it++){
        h16 v[2*R-1],g[2*R-1]={0};
        for(int k=0;k<R;k++)v[N+k]=x[(it*R+k)&1023];
        for(int j=N-1;j>=0;j--){const h16*q=p+4*j;h16 a=v[2*j+1],b=v[2*j+2];
            v[j]=(h16)((1-a)*((1-b)*q[0]+b*q[1])+a*((1-b)*q[2]+b*q[3]));}
        g[0]=(h16)1;
        for(int j=0;j<N;j++){h16 a=v[2*j+1],b=v[2*j+2],u=g[j];const h16*q=p+4*j;
            acc[4*j]+=(h16)(u*(1-a)*(1-b));acc[4*j+1]+=(h16)(u*(1-a)*b);
            acc[4*j+2]+=(h16)(u*a*(1-b));acc[4*j+3]+=(h16)(u*a*b);
            g[2*j+1]=(h16)(u*((1-b)*(q[2]-q[0])+b*(q[3]-q[1])));
            g[2*j+2]=(h16)(u*((1-a)*(q[1]-q[0])+a*(q[3]-q[2])));}
        for(int k=0;k<R;k++)s+=g[N+k];
    }return (float)s;
}
#endif
/* C: fp32 but B lanes of batch at once -- same tree, same indices, vectorizable */
static float lane32(const float *x,const float *p,int iters,float *acc){
    float s=0;
    for(int it=0;it<iters;it++){
        float v[2*R-1][B],g[2*R-1][B];
        for(int k=0;k<R;k++)for(int l=0;l<B;l++)v[N+k][l]=x[((it*R+k)*B+l)&8191];
        for(int j=N-1;j>=0;j--){const float*q=p+4*j;
            for(int l=0;l<B;l++){float a=v[2*j+1][l],b=v[2*j+2][l];
                v[j][l]=(1-a)*((1-b)*q[0]+b*q[1])+a*((1-b)*q[2]+b*q[3]);}}
        for(int l=0;l<B;l++)g[0][l]=1.f;
        for(int j=0;j<N;j++){const float*q=p+4*j;float d0=0,d1=0,d2=0,d3=0;
            for(int l=0;l<B;l++){float a=v[2*j+1][l],b=v[2*j+2][l],u=g[j][l];
                d0+=u*(1-a)*(1-b);d1+=u*(1-a)*b;d2+=u*a*(1-b);d3+=u*a*b;
                g[2*j+1][l]=u*((1-b)*(q[2]-q[0])+b*(q[3]-q[1]));
                g[2*j+2][l]=u*((1-a)*(q[1]-q[0])+a*(q[3]-q[2]));}
            acc[4*j]+=d0;acc[4*j+1]+=d1;acc[4*j+2]+=d2;acc[4*j+3]+=d3;}
        for(int k=0;k<R;k++)for(int l=0;l<B;l++)s+=g[N+k][l];
    }return s;
}
int main(void){
    static float x32[8192],p32[4*N],a32[4*N];
    for(int i=0;i<8192;i++)x32[i]=(float)((i*37%100)/100.);
    for(int i=0;i<4*N;i++)p32[i]=(float)((i*13%100)/100.);
    int iters=20000;
    double t=now();volatile float r1=0;for(int r=0;r<REP;r++)r1+=scalar32(x32,p32,iters,a32);
    double dA=now()-t;
    printf("A scalar fp32, 1 sample/tree : %.3f s  -> %.1f Mtrees/s\n",dA,REP*(double)iters/dA/1e6);
#if defined(__AVX512FP16__)
    { static _Float16 x16[8192],p16[4*N],a16[4*N];
      for(int i=0;i<8192;i++)x16[i]=(_Float16)x32[i];
      for(int i=0;i<4*N;i++)p16[i]=(_Float16)p32[i];
      t=now();volatile float r2=0;for(int r=0;r<REP;r++)r2+=scalar16(x16,p16,iters,a16);
      double dB=now()-t;
      printf("B scalar fp16, 1 sample/tree : %.3f s  -> %.1f Mtrees/s  (%.2fx vs A)\n",dB,REP*(double)iters/dB/1e6,dA/dB); }
#else
    printf("B scalar fp16: not compiled (no __AVX512FP16__)\n");
#endif
    t=now();volatile float r3=0;for(int r=0;r<REP;r++)r3+=lane32(x32,p32,iters/B,a32);
    double dC=now()-t;
    printf("C fp32, %d batch lanes/tree : %.3f s  -> %.1f Mtrees/s  (%.2fx vs A)\n",B,dC,REP*(double)(iters/B)*B/dC/1e6,dA/dC);
    return 0;
}
