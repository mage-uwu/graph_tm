/* prof.c: split the training step into forward / backward / adam.
 * usage: prof MODEL.ltc DATA.tsv REPS */
#define LOGIC_NO_MAIN
#include "logic_text.c"
int main(int argc,char **argv) {
    if(argc<4)die("usage: prof MODEL.ltc DATA.tsv REPS");
    int reps=(int)parse_long(argv[3],1,10000);
    Net *n=load_net(argv[1]);n->c.stage=0;
    Data d=data_load(argv[2],"tsv",&n->vocab,n->c.vocab,n->c.seq);
    Work *w=work_new(n,n->c.batch,n->c.seq);
    for(int b=0;b<w->B;b++){int i=randint(&n->rng,d.n);
        memcpy(w->ids+(size_t)b*w->T,d.x+(size_t)i*d.T,w->T*4);w->labels[b]=d.y[i];}
    double tf=0,tb=0,ta=0,tenc=0;float ce;
    for(int r=0;r<reps;r++) {
        double t0=now();encode(n,w);double t1=now();                 /* codes + all blocks fwd */
        supervised(n,w,0,NULL);double t2=now();                      /* + pool/head fwd (re-encodes) */
        objective(n,w,.002f,1,&ce);double t3=now();                  /* full fwd+bwd */
        adam(n,.01f);double t4=now();
        tenc+=t1-t0;tf+=t2-t1;tb+=t3-t2;ta+=t4-t3;
    }
    double fwd=tenc+ (tf);                       /* one full forward ~= encode + head */
    printf("per step over %d reps (batch %d, seq %d, width %d):\n",reps,w->B,w->T,n->c.width);
    printf("  encode+blocks forward : %.4f s\n",tenc/reps);
    printf("  full forward (no grad): %.4f s\n",tf/reps);
    printf("  forward+backward      : %.4f s\n",tb/reps);
    printf("  backward alone (est)  : %.4f s  (%.1fx forward)\n",(tb-tf)/reps,(tb-tf)/tf);
    printf("  adam update           : %.4f s\n",ta/reps);
    printf("  fwd share %.0f%%, bwd share %.0f%%, adam share %.0f%%\n",
           100*tf/(tb+ta),100*(tb-tf)/(tb+ta),100*ta/(tb+ta));
    (void)fwd;return 0;
}
