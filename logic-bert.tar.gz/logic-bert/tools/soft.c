/* soft.c: soft (relaxed, float) vs hard (Boolean) accuracy of one .ltc checkpoint.
 * usage: soft MODEL.ltc DATA.tsv SEQ */
#define LOGIC_NO_MAIN
#include "logic_text.c"
int main(int argc,char **argv) {
    if(argc<4)die("usage: soft MODEL.ltc DATA.tsv SEQ");
    int T=(int)parse_long(argv[3],1,65536),B=32;
    Net *n=load_net(argv[1]);n->c.stage=0;
    Data d=data_load(argv[2],"tsv",&n->vocab,n->c.vocab,T);
    Work *w=work_new(n,B,T);int hit=0,tot=0;
    for(int i=0;i+B<=d.n;i+=B){
        memcpy(w->ids,d.x+(size_t)i*T,(size_t)B*T*4);memcpy(w->labels,d.y+i,B*sizeof(int));
        int c;supervised(n,w,0,&c);hit+=c;tot+=B;
    }
    Hard *h=harden(n);double hard=eval_hard(h,&d,64,0);
    printf("%s on %s seq %d: soft=%.4f hard=%.4f (temperature %.2f)\n",argv[1],argv[2],T,(double)hit/tot,hard,n->temperature);
    return 0;
}
