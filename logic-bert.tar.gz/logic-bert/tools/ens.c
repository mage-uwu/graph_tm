/* ens.c: evaluate an ensemble of .lth models by summing integer class votes.
 * usage: ens DATA.tsv SEQ model1.lth [model2.lth ...]
 * Each model tokenizes with its own embedded vocabulary. Float-free inference. */
#define LOGIC_NO_MAIN
#include "logic_text.c"
int main(int argc,char **argv) {
    if(argc<4)die("usage: ens DATA.tsv SEQ model.lth...");
    int T=(int)parse_long(argv[2],1,65536),M=argc-3,B=64;
    int64_t *sum=NULL;int *y=NULL,n=0;
    for(int m=0;m<M;m++) {
        Hard *h=load_hard(argv[3+m]);
        Data d=data_load(argv[1],"tsv",&h->vocab,h->c.vocab,T);
        if(!sum){n=d.n;sum=alloc(mul(n,2),8);y=alloc(n,sizeof(int));memcpy(y,d.y,n*sizeof(int));}
        HWork *w=hwork_new(h,B,T);uint32_t *tail=alloc(mul(B,T),4);int hit=0;
        for(int i=0;i<n;i+=B) {
            int take=n-i<B?n-i:B;const uint32_t *x=d.x+(size_t)i*T;
            if(take<B){memset(tail,0,(size_t)B*T*4);memcpy(tail,x,(size_t)take*T*4);x=tail;}
            hard_predict(h,w,x);
            for(int j=0;j<take;j++){
                sum[2*(i+j)]+=w->scores[2*j];sum[2*(i+j)+1]+=w->scores[2*j+1];
                hit+=(w->scores[2*j+1]>w->scores[2*j])==y[i+j];
            }
        }
        int ens=0;for(int i=0;i<n;i++)ens+=(sum[2*i+1]>sum[2*i])==y[i];
        printf("%-14s alone=%.4f  ensemble_of_first_%d=%.4f\n",argv[3+m],(double)hit/n,m+1,(double)ens/n);
        free(tail);hwork_free(w);data_free(&d);hard_free(h);
    }
    free(sum);free(y);return 0;
}
