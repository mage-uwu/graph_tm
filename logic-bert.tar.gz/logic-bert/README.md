# logic-bert

Differentiable logic gate network (DDLGN) text classifier in standalone C11, being scaled
to a BERT-style pretrain → fine-tune test against BERT-Tiny.

Quick start:
```
make all && make data && make check
```
- `CLAUDE.md`  — briefing, invariants, evaluation hygiene (read first)
- `RESULTS.md` — every number measured so far
- `TASKS.md`   — prioritized work queue with acceptance criteria

Requirements: gcc (with OpenMP), make, curl, python3 with pandas, openpyxl, scikit-learn, scipy.
