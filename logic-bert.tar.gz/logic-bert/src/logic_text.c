/*
 * logic_text.c -- standalone learned-code convolutional logic classifier.
 * (verbatim copy of user-supplied source; header comment abbreviated)
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <float.h>
#include <stdarg.h>
#ifdef _OPENMP
#include <omp.h>
#endif
#define MAX_DEPTH 5
#define MAX_LEAVES 32
#define MAX_BLOCKS 32
#define PI 3.14159265358979323846
#define PAD 0
#define MASK 1
#define UNK 2
#define MAX_RECORD ((size_t)64*1024*1024)

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap,fmt); fputs("error: ",stderr);
    vfprintf(stderr,fmt,ap); va_end(ap); fputc('\n',stderr); exit(EXIT_FAILURE);
}
static size_t mul(size_t a,size_t b) {
    if(b && a>SIZE_MAX/b) die("size overflow");
    return a*b;
}
static void *alloc(size_t n,size_t s) {
    size_t k=mul(n,s); void *p=calloc(k?k:1,1);
    if(!p) die("cannot allocate %zu bytes",k);
    return p;
}
static void *resize(void *p,size_t n,size_t s) {
    void *q=realloc(p,mul(n,s)); if(!q) die("reallocation failed"); return q;
}
static char *copystr(const char *s) {
    char *p=alloc(strlen(s)+1,1); strcpy(p,s); return p;
}
static double now(void) {
    struct timespec t;
    if(clock_gettime(CLOCK_MONOTONIC,&t)) die("monotonic clock failed");
    return t.tv_sec+1e-9*t.tv_nsec;
}
static void threads_set(int n) {
#ifdef _OPENMP
    omp_set_dynamic(0); omp_set_num_threads(n);
#else
    if(n!=1) fprintf(stderr,"note: compiled without OpenMP; using one thread\n");
#endif
}
static int thread_count(void) {
#ifdef _OPENMP
    return omp_get_max_threads();
#else
    return 1;
#endif
}
typedef struct { uint64_t s; } RNG;
static uint64_t ru(RNG *r) {
    uint64_t x=r->s; x^=x>>12; x^=x<<25; x^=x>>27; r->s=x;
    return x*UINT64_C(2685821657736338717);
}
static float uniform(RNG *r) { return (float)(ru(r)>>40)*(1.f/16777216.f); }
static int randint(RNG *r,int n) { return (int)(ru(r)%(uint64_t)n); }
static float normal(RNG *r) {
    return sqrtf(-2.f*logf(fmaxf(uniform(r),1e-7f)))*cosf((float)(2*PI)*uniform(r));
}
static float sigmoid(float x) {
    if(x>=0) return 1.f/(1.f+expf(-x));
    float e=expf(x); return e/(1.f+e);
}
static float corner(float x,int est) { return est?.5f+.5f*sinf(x):sigmoid(x); }
static float cderiv(float x,float p,int est) { return est?.5f*cosf(x):p*(1.f-p); }
static float gate(float a,float b,const float *p) {
    return (1-a)*((1-b)*p[0]+b*p[1])+a*((1-b)*p[2]+b*p[3]);
}
static uint64_t gate64(uint64_t a,uint64_t b,uint8_t f) {
    return (~a&~b&-(uint64_t)(f&1)) | (~a&b&-(uint64_t)((f>>1)&1)) |
           (a&~b&-(uint64_t)((f>>2)&1)) | (a&b&-(uint64_t)((f>>3)&1));
}
static int lowbit(uint64_t x) {
#if defined(__GNUC__) || defined(__clang__)
    return __builtin_ctzll(x);
#else
    int n=0; while(!(x&1)){x>>=1;n++;} return n;
#endif
}

typedef struct {
    int vocab,bits,width,blocks,depth,kernel,cycle,votes,est,q8;
    int seq,batch,steps,stage,max_targets;
    float peak_lr,sharp,clip,mask_prob,scale,mlm_scale;
} Config;
static Config defaults(void) {
    Config c={8192,64,128,8,3,3,8,128,0,0,128,16,1000,0,0,
              .025f,.002f,5.f,.15f,16.f,16.f}; return c;
}
static void validate(Config c) {
    if(c.vocab<4 || c.vocab>1000000 || c.bits<2 || c.bits>1024 || c.bits%2 ||
       c.width<1 || c.width>65536 || c.blocks<1 || c.blocks>MAX_BLOCKS ||
       c.depth<1 || c.depth>MAX_DEPTH || c.kernel<1 || c.kernel>31 || !(c.kernel%2) ||
       c.cycle<1 || c.cycle>20 || c.votes<1 || c.votes>32768 ||
       c.est<0 || c.est>1 || c.q8<0 || c.q8>1 || c.seq<1 || c.seq>65536 ||
       c.batch<1 || c.batch>65536 || c.steps<1 || c.steps>1000000000 ||
       c.stage<0 || c.stage>1 || c.max_targets<0 ||
       !(c.peak_lr>0) || !isfinite(c.peak_lr) || !(c.sharp>=0) || !isfinite(c.sharp) ||
       !(c.clip>0) || !isfinite(c.clip) || !(c.mask_prob>0 && c.mask_prob<=1) ||
       !(c.scale>0) || !isfinite(c.scale) || !(c.mlm_scale>0) || !isfinite(c.mlm_scale) ||
       (int64_t)c.batch*c.seq>INT_MAX || (int64_t)c.seq*c.votes>INT_MAX/2)
        die("invalid or excessive model/training dimensions");
}
typedef struct { size_t n; float *z,*g,*m,*v; uint64_t t; } Param;
static Param param_new(size_t n,int training) {
    Param p={0}; p.n=n; p.z=alloc(n,4);
    if(training){p.g=alloc(n,4);p.m=alloc(n,4);p.v=alloc(n,4);} return p;
}
static void param_free(Param *p) { free(p->z);free(p->g);free(p->m);free(p->v);memset(p,0,sizeof *p); }
typedef struct {
    int C,O,d,dilation,kernel,R,N;
    int32_t *ch,*off;
    Param p;
    float *corners;
} Layer;
static Layer layer_new(int C,int O,int d,int dilation,int kernel,int train) {
    Layer l={0}; l.C=C;l.O=O;l.d=d;l.dilation=dilation;l.kernel=kernel;
    l.R=1<<d;l.N=l.R-1;
    l.ch=alloc(mul(O,l.R),4);l.off=alloc(mul(O,l.R),4);
    l.p=param_new(mul(mul(O,l.N),4),train);l.corners=alloc(l.p.n,4);return l;
}
static void layer_init(Layer *l,int est,int anchor,RNG *r) {
    int rad=l->kernel/2;
    for(int o=0;o<l->O;o++) {
        int first=anchor?o%l->C:randint(r,l->C);
        int second=(first+1+randint(r,l->C>1?l->C-1:1))%l->C;
        for(int k=0;k<l->R;k++) {
            l->ch[o*l->R+k]=randint(r,2)?second:first;
            l->off[o*l->R+k]=randint(r,l->kernel)-rad;
        }
        l->ch[o*l->R]=first;l->off[o*l->R]=0;
        if(l->R>=4 && rad){l->off[o*l->R+1]=-rad;l->off[o*l->R+2]=rad;}
    }
    float mu=est?1.2f:3.f,sd=est?.25f:.5f;
    for(size_t k=0;k<l->p.n;k++) l->p.z[k]=((k%4)<2?-1.f:1.f)*(mu+sd*normal(r));
}
static void layer_free(Layer *l) {free(l->ch);free(l->off);free(l->corners);param_free(&l->p);}
typedef struct { int n; char **words; int32_t *slot; size_t cap; } Vocab;
static uint64_t hashword(const char *s) {
    uint64_t h=UINT64_C(1469598103934665603);
    for(;*s;s++){h^=(unsigned char)*s;h*=UINT64_C(1099511628211);}return h;
}
static void vocab_index(Vocab *v) {
    free(v->slot);v->cap=16;while(v->cap<(size_t)v->n*3)v->cap*=2;
    v->slot=alloc(v->cap,4);
    for(int i=0;i<v->n;i++) if(v->words[i] && *v->words[i]) {
        size_t j=hashword(v->words[i])&(v->cap-1);
        while(v->slot[j]) {
            if(!strcmp(v->words[v->slot[j]-1],v->words[i])) die("duplicate vocabulary word: %s",v->words[i]);
            j=(j+1)&(v->cap-1);
        }v->slot[j]=i+1;
    }
}
static int vocab_lookup(const Vocab *v,const char *s) {
    if(!v->n)return UNK;
    size_t j=hashword(s)&(v->cap-1);
    while(v->slot[j]){int i=v->slot[j]-1;if(!strcmp(s,v->words[i]))return i;j=(j+1)&(v->cap-1);}return UNK;
}
static void vocab_free(Vocab *v) {for(int i=0;i<v->n;i++)free(v->words[i]);free(v->words);free(v->slot);memset(v,0,sizeof *v);}
typedef struct {
    Config c; Layer *l; Param emb,bias; float *codes;
    float temperature,best_val; uint64_t step; RNG rng; Vocab vocab;
} Net;
static Net *net_new(Config c,int training,int initialize,uint64_t seed) {
    validate(c);Net *n=alloc(1,sizeof *n);n->c=c;n->rng.s=seed?seed:1;
    n->temperature=1;n->best_val=-1;
    n->emb=param_new(mul(c.vocab,c.bits),training);n->bias=param_new(c.vocab-3,training);
    n->codes=alloc(n->emb.n,4);n->l=alloc(c.blocks+2,sizeof(Layer));
    for(int i=0;i<c.blocks;i++)n->l[i]=layer_new(i?c.width:c.bits,c.width,c.depth,1<<(i%c.cycle),c.kernel,training);
    n->l[c.blocks]=layer_new(c.width,c.bits,2,1,1,training);
    n->l[c.blocks+1]=layer_new(c.width,2*c.votes,c.depth,1,1,training);
    if(initialize) {
        int *perm=alloc(c.bits,sizeof(int));
        for(int v=0;v<c.vocab;v++) {
            for(int k=0;k<c.bits;k++){perm[k]=k;n->emb.z[(size_t)v*c.bits+k]=.8f;}
            for(int k=c.bits-1;k>0;k--){int j=randint(&n->rng,k+1),a=perm[k];perm[k]=perm[j];perm[j]=a;}
            for(int k=0;k<c.bits/2;k++)n->emb.z[(size_t)v*c.bits+perm[k]]=-.8f;
        }free(perm);memset(n->emb.z,0,c.bits*4);
        for(int i=0;i<c.blocks+2;i++)layer_init(&n->l[i],c.est,i!=c.blocks+1,&n->rng);
    }return n;
}
static void net_free(Net *n) {
    if(!n)return;
    for(int i=0;i<n->c.blocks+2;i++)layer_free(n->l+i);
    free(n->l);free(n->codes);param_free(&n->emb);param_free(&n->bias);vocab_free(&n->vocab);free(n);
}
static void refresh(Net *n) {
    float temp=fmaxf(.05f,n->temperature);
    #pragma omp parallel for schedule(static)
    for(size_t k=0;k<n->emb.n;k++)n->codes[k]=k<(size_t)n->c.bits?0:sigmoid(n->emb.z[k]/temp);
    for(int i=0;i<n->c.blocks+2;i++) {
        Layer *l=n->l+i;
        for(size_t k=0;k<l->p.n;k++)l->corners[k]=corner(l->p.z[k],n->c.est);
    }
}
/* Lane-major activations: X[((size_t)t*C+c)*B+b]. Batch lanes are contiguous, so
 * the inner loop over lanes vectorizes and the gather indices, which depend only
 * on (o,t), are computed once per tree instead of once per batch element.
 * Accumulation order per lane is unchanged, so results are bitwise identical. */
#define LANES 16
static void tree_leaves(const Layer *l,int T,int t,int o,int32_t *base) {
    for(int k=0;k<l->R;k++) {
        int s=t+l->off[o*l->R+k]*l->dilation;
        base[k]=(s<0||s>=T)?-1:(int32_t)((size_t)s*l->C+l->ch[o*l->R+k]);
    }
}
static void tree_forward(const Layer *l,const float *x,const int32_t *base,const float *p,
                         int B,int b0,int nl,int q8,float v[][LANES]) {
    for(int k=0;k<l->R;k++) {
        float *dst=v[l->N+k];
        if(base[k]<0){for(int e=0;e<nl;e++)dst[e]=0.f;continue;}
        const float *src=x+(size_t)base[k]*B+b0;
        for(int e=0;e<nl;e++)dst[e]=src[e];
    }
    for(int j=l->N-1;j>=0;j--) {
        const float *q=p+4*j;const float *a=v[2*j+1],*bb=v[2*j+2];float *out=v[j];
        for(int e=0;e<nl;e++) {
            float r=(1-a[e])*((1-bb[e])*q[0]+bb[e]*q[1])+a[e]*((1-bb[e])*q[2]+bb[e]*q[3]);
            out[e]=q8?nearbyintf(r*255.f)/255.f:r;
        }
    }
}
static void forward_layer(const Layer *l,const float *x,float *y,const uint8_t *valid,int B,int T,int q8) {
    int O=l->O;
    #pragma omp parallel for schedule(static)
    for(int t=0;t<T;t++) for(int o=0;o<O;o++) {
        int32_t base[MAX_LEAVES];tree_leaves(l,T,t,o,base);
        const float *p=l->corners+(size_t)o*l->N*4;
        for(int b0=0;b0<B;b0+=LANES) {
            int nl=B-b0<LANES?B-b0:LANES;
            float v[2*MAX_LEAVES-1][LANES];
            tree_forward(l,x,base,p,B,b0,nl,q8,v);
            float *dst=y+((size_t)t*O+o)*B+b0;
            for(int e=0;e<nl;e++)dst[e]=valid[(size_t)(b0+e)*T+t]?v[0][e]:0.f;
        }
    }
}
static void backward_layer(Layer *l,const float *x,const float *dy,float *dx,float *partial,
                           const uint8_t *valid,int B,int T,int q8,int est) {
    int O=l->O,N=l->N;
    memset(dx,0,mul(mul(B,T),l->C)*4);memset(partial,0,mul(B,l->p.n)*4);
    /* partial is lane-major too: partial[(size_t)k*B+b] for parameter index k. */
    #pragma omp parallel for schedule(static)
    for(int b0=0;b0<B;b0+=LANES)
    for(int o=0;o<O;o++)for(int t=0;t<T;t++) {
        int32_t base[MAX_LEAVES];tree_leaves(l,T,t,o,base);
        const float *p=l->corners+(size_t)o*l->N*4;
        {
            int nl=B-b0<LANES?B-b0:LANES;
            float v[2*MAX_LEAVES-1][LANES],g[2*MAX_LEAVES-1][LANES];
            tree_forward(l,x,base,p,B,b0,nl,q8,v);
            const float *up=dy+((size_t)t*O+o)*B+b0;
            for(int e=0;e<nl;e++)g[0][e]=valid[(size_t)(b0+e)*T+t]?up[e]:0.f;
            for(int j=0;j<N;j++) {
                const float *q=p+4*j,*a=v[2*j+1],*bb=v[2*j+2],*u=g[j];
                float *d0=partial+(size_t)(((size_t)o*N+j)*4+0)*B+b0;
                float *d1=partial+(size_t)(((size_t)o*N+j)*4+1)*B+b0;
                float *d2=partial+(size_t)(((size_t)o*N+j)*4+2)*B+b0;
                float *d3=partial+(size_t)(((size_t)o*N+j)*4+3)*B+b0;
                float *ga=g[2*j+1],*gb=g[2*j+2];
                for(int e=0;e<nl;e++) {
                    d0[e]+=u[e]*(1-a[e])*(1-bb[e]);d1[e]+=u[e]*(1-a[e])*bb[e];
                    d2[e]+=u[e]*a[e]*(1-bb[e]);d3[e]+=u[e]*a[e]*bb[e];
                    ga[e]=u[e]*((1-bb[e])*(q[2]-q[0])+bb[e]*(q[3]-q[1]));
                    gb[e]=u[e]*((1-a[e])*(q[1]-q[0])+a[e]*(q[3]-q[2]));
                }
            }
            for(int k=0;k<l->R;k++) {
                if(base[k]<0)continue;
                float *d=dx+(size_t)base[k]*B+b0;const float *s=g[N+k];
                for(int e=0;e<nl;e++)d[e]+=s[e];
            }
        }
    }
    #pragma omp parallel for schedule(static)
    for(size_t k=0;k<l->p.n;k++) {
        double s=0;for(int b=0;b<B;b++)s+=partial[k*(size_t)B+b];
        l->p.g[k]=(float)s*cderiv(l->p.z[k],l->corners[k],est);
    }
}

typedef struct {
    int B,T,U,maxC;size_t max_param;
    float **a,*pool,*head,*proj,*g0,*g1,*partial,*code_grad,*logits;
    uint8_t *valid,*pv,*selected;uint32_t *ids,*targets;int *labels;
} Work;
static Work *work_new(Net *n,int B,int T) {
    Work *w=alloc(1,sizeof *w);w->B=B;w->T=T;w->U=(T+1)/2;
    int K=n->c.blocks,C=n->c.bits,W=n->c.width;
    w->maxC=W>C?W:C;if(w->maxC<2*n->c.votes)w->maxC=2*n->c.votes;
    w->a=alloc(K+1,sizeof(float*));
    for(int i=0;i<=K;i++)w->a[i]=alloc(mul(mul(B,T),i?W:C),4);
    for(int i=0;i<K+2;i++)if(n->l[i].p.n>w->max_param)w->max_param=n->l[i].p.n;
    w->pool=alloc(mul(mul(B,w->U),W),4);w->head=alloc(mul(mul(B,w->U),2*n->c.votes),4);
    w->proj=alloc(mul(mul(B,T),C),4);w->g0=alloc(mul(mul(B,T),w->maxC),4);w->g1=alloc(mul(mul(B,T),w->maxC),4);
    w->partial=alloc(mul(B,w->max_param),4);w->code_grad=alloc(n->emb.n,4);w->logits=alloc(n->c.vocab,4);
    w->valid=alloc(mul(B,T),1);w->pv=alloc(mul(B,w->U),1);w->selected=alloc(mul(B,T),1);
    w->ids=alloc(mul(B,T),4);w->targets=alloc(mul(B,T),4);w->labels=alloc(B,sizeof(int));return w;
}
static void work_free(Work *w,int K) {
    for(int i=0;i<=K;i++)free(w->a[i]);
    free(w->a);free(w->pool);free(w->head);free(w->proj);
    free(w->g0);free(w->g1);free(w->partial);free(w->code_grad);free(w->logits);free(w->valid);free(w->pv);
    free(w->selected);free(w->ids);free(w->targets);free(w->labels);free(w);
}
static void encode(Net *n,Work *w) {
    int C=n->c.bits;refresh(n);
    #pragma omp parallel for schedule(static)
    for(size_t j=0;j<(size_t)w->B*w->T;j++) {
        uint32_t id=w->ids[j];if(id>=(uint32_t)n->c.vocab)die("token ID outside vocabulary");
        w->valid[j]=id!=PAD;
        int b=(int)(j/(size_t)w->T),t=(int)(j%(size_t)w->T);
        for(int k=0;k<C;k++) {
            float a=n->codes[(size_t)id*C+k];
            w->a[0][((size_t)t*C+k)*w->B+b]=n->c.q8?nearbyintf(a*255.f)/255.f:a;
        }
    }
    for(int i=0;i<n->c.blocks;i++)forward_layer(n->l+i,w->a[i],w->a[i+1],w->valid,w->B,w->T,n->c.q8);
}
static void pool_forward(Net *n,Work *w) {
    int C=n->c.width,T=w->T,U=w->U;
    const float *x=w->a[n->c.blocks];
    for(int b=0;b<w->B;b++)for(int u=0;u<U;u++) {
        int t=2*u;w->pv[b*U+u]=w->valid[b*T+t] | (t+1<T?w->valid[b*T+t+1]:0);
        for(int c=0;c<C;c++)w->pool[((size_t)u*C+c)*w->B+b]=
            fmaxf(x[((size_t)t*C+c)*w->B+b],t+1<T?x[((size_t)(t+1)*C+c)*w->B+b]:0.f);
    }
}
static void pool_backward(Net *n,Work *w,const float *dy,float *dx) {
    int C=n->c.width,T=w->T,U=w->U;const float *x=w->a[n->c.blocks];
    memset(dx,0,(size_t)w->B*T*C*4);
    for(int b=0;b<w->B;b++)for(int u=0;u<U;u++)for(int c=0;c<C;c++) {
        int t=2*u;size_t i=((size_t)t*C+c)*w->B+b,i2=((size_t)(t+1)*C+c)*w->B+b;
        float a=x[i],bb=t+1<T?x[i2]:0,g=dy[((size_t)u*C+c)*w->B+b];
        dx[i]=g*(a>bb?1.f:a==bb?.5f:0.f);
        if(t+1<T)dx[i2]=g*(bb>a?1.f:a==bb?.5f:0.f);
    }
}
static float supervised(Net *n,Work *w,int grad,int *correct) {
    encode(n,w);pool_forward(n,w);int O=2*n->c.votes;
    forward_layer(n->l+n->c.blocks+1,w->pool,w->head,w->pv,w->B,w->U,n->c.q8);
    double loss=0;int hit=0;
    for(int b=0;b<w->B;b++) {
        int count=0,y=w->labels[b];if(y<0||y>1)die("supervised training requires labels 0 or 1");
        double sum[2]={0,0};
        for(int u=0;u<w->U;u++) {
            count+=w->pv[b*w->U+u];
            for(int o=0;o<O;o++)sum[o/n->c.votes]+=w->head[((size_t)u*O+o)*w->B+b];
        }
        float scale=n->c.scale/((count?count:1)*n->c.votes);
        float d=(float)(sum[1]-sum[0])*scale,p=sigmoid(d);
        loss+=fmaxf(d,0)+log1pf(expf(-fabsf(d)))-y*d;hit+=(d>0)==y;
        if(grad)for(int u=0;u<w->U;u++)for(int o=0;o<O;o++)
            w->g0[((size_t)u*O+o)*w->B+b]=(o<n->c.votes?-1.f:1.f)*(p-y)*scale/w->B*w->pv[b*w->U+u];
    }
    if(correct)*correct=hit;
    if(grad) {
        backward_layer(n->l+n->c.blocks+1,w->pool,w->g0,w->g1,w->partial,w->pv,w->B,w->U,n->c.q8,n->c.est);
        pool_backward(n,w,w->g1,w->g0);
    }return (float)(loss/w->B);
}
static int corrupt(Net *n,Work *w) {
    size_t count=(size_t)w->B*w->T;memcpy(w->targets,w->ids,count*4);memset(w->selected,0,count);
    int total=0,eligible=0,last=-1;
    for(size_t i=0;i<count;i++)if(w->ids[i]>=3) {
        eligible++;if(randint(&n->rng,eligible)==0)last=(int)i;
        if(uniform(&n->rng)<n->c.mask_prob){w->selected[i]=1;total++;}
    }
    if(!eligible)die("MLM batch has no known real tokens (IDs >=3)");
    if(!total){w->selected[last]=1;total=1;}
    if(n->c.max_targets && total>n->c.max_targets) {
        int remaining=total,keep=n->c.max_targets;
        for(size_t i=0;i<count;i++)if(w->selected[i]) {
            if(randint(&n->rng,remaining)<keep)keep--;else w->selected[i]=0;
            remaining--;
        }
        total=n->c.max_targets;
    }
    for(size_t i=0;i<count;i++)if(w->selected[i]) {
        float u=uniform(&n->rng);
        if(u<.8f)w->ids[i]=MASK;else if(u<.9f)w->ids[i]=3+randint(&n->rng,n->c.vocab-3);
    }
    return total;
}
static float masked_loss(Net *n,Work *w,int grad) {
    encode(n,w);int C=n->c.bits,V=n->c.vocab,K=n->c.blocks;
    forward_layer(n->l+K,w->a[K],w->proj,w->valid,w->B,w->T,n->c.q8);
    size_t BT=(size_t)w->B*w->T;int count=0;
    for(size_t i=0;i<BT;i++)count+=w->selected[i];
    if(!count)die("no MLM targets");
    if(grad){memset(w->g0,0,BT*C*4);memset(n->bias.g,0,n->bias.n*4);}
    float scale=n->c.mlm_scale/C;double loss=0;
    /* Phase A (parallel over targets): logits, softmax numerators, denominators.
     * Phase B (parallel over targets): gradient into the projection output.
     * Phase C (parallel over vocabulary rows): bias and code gradients, summing
     * targets in ascending order. Same per-element accumulation order as the
     * serial loop, so results are bitwise identical at any thread count. */
    size_t *tix=alloc(count,sizeof(size_t));
    {int c=0;for(size_t i=0;i<BT;i++)if(w->selected[i])tix[c++]=i;}
    int Vr=V-3;float *ex=alloc(mul(count,Vr),4);double *den=alloc(count,8),*lt=alloc(count,8);
    #pragma omp parallel for schedule(static)
    for(int c=0;c<count;c++) {
        size_t i=tix[c];uint32_t target=w->targets[i];
        if(target<3||target>=(uint32_t)V)die("invalid MLM target");
        int bi=(int)(i/(size_t)w->T),ti=(int)(i%(size_t)w->T);
        const float *h=w->proj+(size_t)ti*C*w->B+bi;int hs=w->B;float mx=-FLT_MAX;
        float *e=ex+(size_t)c*Vr;
        for(int v=3;v<V;v++) {
            float sc=0;const float *cv=n->codes+(size_t)v*C;
            for(int k=0;k<C;k++)sc+=(2*h[(size_t)k*hs]-1)*(2*cv[k]-1);
            e[v-3]=scale*sc+n->bias.z[v-3];if(e[v-3]>mx)mx=e[v-3];
        }
        float target_logit=e[target-3];double denom=0;
        for(int v=3;v<V;v++){e[v-3]=expf(e[v-3]-mx);denom+=e[v-3];}
        den[c]=denom;lt[c]=log(denom)+mx-target_logit;
    }
    for(int c=0;c<count;c++)loss+=lt[c];
    if(grad) {
        #pragma omp parallel for schedule(static)
        for(int c=0;c<count;c++) {
            size_t i=tix[c];uint32_t target=w->targets[i];
            int bi=(int)(i/(size_t)w->T),ti=(int)(i%(size_t)w->T);const float *e=ex+(size_t)c*Vr;
            for(int v=3;v<V;v++) {
                float g=((float)(e[v-3]/den[c])-(v==(int)target))/count;
                for(int k=0;k<C;k++)w->g0[((size_t)ti*C+k)*w->B+bi]+=2*scale*g*(2*n->codes[(size_t)v*C+k]-1);
            }
        }
        #pragma omp parallel for schedule(static)
        for(int v=3;v<V;v++) {
            for(int c=0;c<count;c++) {
                size_t i=tix[c];uint32_t target=w->targets[i];
                int bi=(int)(i/(size_t)w->T),ti=(int)(i%(size_t)w->T);
                const float *h=w->proj+(size_t)ti*C*w->B+bi;int hs=w->B;
                float g=((float)(ex[(size_t)c*Vr+v-3]/den[c])-(v==(int)target))/count;
                n->bias.g[v-3]+=g;
                for(int k=0;k<C;k++)w->code_grad[(size_t)v*C+k]+=2*scale*g*(2*h[(size_t)k*hs]-1);
            }
        }
    }
    free(tix);free(ex);free(den);free(lt);
    if(grad) {
        backward_layer(n->l+K,w->a[K],w->g0,w->g1,w->partial,w->valid,w->B,w->T,n->c.q8,n->c.est);
        memcpy(w->g0,w->g1,(size_t)w->B*w->T*n->c.width*4);
    }return (float)(loss/count);
}
static float regularizer(Net *n,Work *w,float sharp,int grad) {
    int C=n->c.bits,V=n->c.vocab,M=V-3;double row=0,col=0,binary=0;
    float *cm=alloc(C,4),*rm=alloc(M,4);
    for(int v=3;v<V;v++) {
        double s=0;for(int k=0;k<C;k++){float p=n->codes[(size_t)v*C+k];s+=p;cm[k]+=p;binary+=p*(1-p);}
        rm[v-3]=(float)(s/C)-.5f;row+=rm[v-3]*rm[v-3];
    }
    for(int k=0;k<C;k++){cm[k]=cm[k]/M-.5f;col+=cm[k]*cm[k];}
    if(grad)for(int v=3;v<V;v++)for(int k=0;k<C;k++) {
        size_t i=(size_t)v*C+k;float p=n->codes[i];
        w->code_grad[i]+=(.2f*(rm[v-3]+cm[k])+sharp*(1-2*p))/((float)M*C);
    }
    free(cm);free(rm);return (float)(.1*(row/M+col/C)+sharp*binary/((double)M*C));
}
static float objective(Net *n,Work *w,float sharp,int grad,float *ce) {
    if(grad)memset(w->code_grad,0,n->emb.n*4);
    *ce=n->c.stage?masked_loss(n,w,grad):supervised(n,w,grad,NULL);
    if(grad) {
        float *g=w->g0,*dx=w->g1;
        for(int i=n->c.blocks-1;i>=0;i--) {
            backward_layer(n->l+i,w->a[i],g,dx,w->partial,w->valid,w->B,w->T,n->c.q8,n->c.est);
            float *swap=g;g=dx;dx=swap;
        }
        for(size_t j=0;j<(size_t)w->B*w->T;j++)if(w->ids[j]!=PAD) {
            int b=(int)(j/(size_t)w->T),t=(int)(j%(size_t)w->T);
            for(int k=0;k<n->c.bits;k++)
                w->code_grad[(size_t)w->ids[j]*n->c.bits+k]+=g[((size_t)t*n->c.bits+k)*w->B+b];
        }
    }
    float reg=regularizer(n,w,sharp,grad);
    if(grad)for(size_t i=0;i<n->emb.n;i++) {
        float p=n->codes[i];n->emb.g[i]=w->code_grad[i]*p*(1-p)/fmaxf(.05f,n->temperature);
    }
    return *ce+reg;
}
static int active_params(Net *n,Param **pp) {
    int k=0;pp[k++]=&n->emb;for(int i=0;i<n->c.blocks;i++)pp[k++]=&n->l[i].p;
    pp[k++]=&n->l[n->c.blocks+(n->c.stage?0:1)].p;
    if(n->c.stage)pp[k++]=&n->bias;
    return k;
}
static void adam(Net *n,float lr) {
    Param *ps[MAX_BLOCKS+3];int np=active_params(n,ps);double norm=0;
    for(int p=0;p<np;p++)for(size_t k=0;k<ps[p]->n;k++) {
        double g=ps[p]->g[k];if(!isfinite(g))die("nonfinite gradient; reduce learning rate");norm+=g*g;
    }
    float clip=(float)fmin(1.,n->c.clip/(sqrt(norm)+1e-6));
    for(int p=0;p<np;p++) {
        Param *a=ps[p];a->t++;double b1=1-pow(.9,(double)a->t),b2=1-pow(.999,(double)a->t);
        #pragma omp parallel for schedule(static)
        for(size_t k=0;k<a->n;k++) {
            float g=a->g[k]*clip;
            a->m[k]=.9f*a->m[k]+.1f*g;a->v[k]=.999f*a->v[k]+.001f*g*g;
            a->z[k]-=lr*(float)(a->m[k]/b1)/(sqrtf((float)(a->v[k]/b2))+1e-8f);
        }
    }
}

/* --------------------------- versioned checkpoints ------------------------ */
static FILE *open_file(const char *path,const char *mode) {
    FILE *f=fopen(path,mode);if(!f)die("%s: %s",path,strerror(errno));return f;
}
static void write_bytes(FILE *f,const void *p,size_t n) {if(n && fwrite(p,1,n,f)!=n)die("checkpoint write failed");}
static void read_bytes(FILE *f,void *p,size_t n) {if(n && fread(p,1,n,f)!=n)die("truncated file");}
static void put32(FILE *f,uint32_t x) {unsigned char a[4];for(int i=0;i<4;i++)a[i]=(unsigned char)(x>>(8*i));write_bytes(f,a,4);}
static uint32_t get32(FILE *f) {unsigned char a[4];read_bytes(f,a,4);uint32_t x=0;for(int i=0;i<4;i++)x|=(uint32_t)a[i]<<(8*i);return x;}
static void put64(FILE *f,uint64_t x) {put32(f,(uint32_t)x);put32(f,(uint32_t)(x>>32));}
static uint64_t get64(FILE *f) {uint64_t lo=get32(f);return lo|((uint64_t)get32(f)<<32);}
static void putfloat(FILE *f,float x) {uint32_t u;memcpy(&u,&x,4);put32(f,u);}
static float getfloat(FILE *f) {uint32_t u=get32(f);float x;memcpy(&x,&u,4);if(!isfinite(x))die("nonfinite checkpoint value");return x;}
static int little_endian(void) {uint32_t x=1;return *(unsigned char*)&x==1;}
static void float_write(FILE *f,const float *x,size_t n) {
    if(little_endian())write_bytes(f,x,mul(n,4));else for(size_t i=0;i<n;i++)putfloat(f,x[i]);
}
static void float_read(FILE *f,float *x,size_t n) {
    if(little_endian())read_bytes(f,x,mul(n,4));else for(size_t i=0;i<n;i++)x[i]=getfloat(f);
    for(size_t i=0;i<n;i++)if(!isfinite(x[i]))die("nonfinite checkpoint tensor");
}
static void config_write(FILE *f,Config c) {
    int a[]={c.vocab,c.bits,c.width,c.blocks,c.depth,c.kernel,c.cycle,c.votes,c.est,c.q8,
             c.seq,c.batch,c.steps,c.stage,c.max_targets};
    float b[]={c.peak_lr,c.sharp,c.clip,c.mask_prob,c.scale,c.mlm_scale};
    for(int i=0;i<15;i++)put32(f,(uint32_t)a[i]);
    for(int i=0;i<6;i++)putfloat(f,b[i]);
}
static Config config_read(FILE *f) {
    Config c={0};int *a[]={&c.vocab,&c.bits,&c.width,&c.blocks,&c.depth,&c.kernel,&c.cycle,&c.votes,&c.est,&c.q8,
                         &c.seq,&c.batch,&c.steps,&c.stage,&c.max_targets};
    float *b[]={&c.peak_lr,&c.sharp,&c.clip,&c.mask_prob,&c.scale,&c.mlm_scale};
    for(int i=0;i<15;i++){uint32_t v=get32(f);if(v>INT_MAX)die("invalid config field");*a[i]=(int)v;}
    for(int i=0;i<6;i++)*b[i]=getfloat(f);
    validate(c);return c;
}
static void vocab_write(FILE *f,const Vocab *v) {
    put32(f,(uint32_t)v->n);
    for(int i=0;i<v->n;i++){size_t len=strlen(v->words[i]);put32(f,(uint32_t)len);write_bytes(f,v->words[i],len);}
}
static Vocab vocab_read(FILE *f,int V) {
    Vocab v={0};uint32_t n=get32(f);if(n>(uint32_t)V || (n && n<3))die("invalid vocabulary size");
    v.n=(int)n;v.words=alloc(n,sizeof(char*));size_t total=0;
    for(int i=0;i<v.n;i++) {
        uint32_t len=get32(f);total+=len;if(!len || len>1048576 || total>MAX_RECORD)die("invalid vocabulary string length");
        v.words[i]=alloc((size_t)len+1,1);read_bytes(f,v.words[i],len);
        if(strlen(v.words[i])!=len)die("embedded NUL in vocabulary");
    }vocab_index(&v);return v;
}
static void param_write(FILE *f,Param p) {
    put64(f,p.n);put64(f,p.t);float_write(f,p.z,p.n);float_write(f,p.m,p.n);float_write(f,p.v,p.n);
}
static void param_read(FILE *f,Param *p) {
    if(get64(f)!=p->n)die("parameter shape mismatch");
    p->t=get64(f);if(p->t>1000000000)die("invalid Adam counter");
    float_read(f,p->z,p->n);float_read(f,p->m,p->n);float_read(f,p->v,p->n);
    for(size_t i=0;i<p->n;i++)if(p->v[i]<0)die("negative Adam second moment");
}
static char *temp_path(const char *path) {
    char *p=alloc(strlen(path)+5,1);sprintf(p,"%s.tmp",path);return p;
}
static void finish_save(FILE *f,char *tmp,const char *path) {
    if(fflush(f))die("flush failed: %s",tmp);
    if(fclose(f))die("close failed: %s",tmp);
    if(rename(tmp,path))die("rename %s -> %s: %s",tmp,path,strerror(errno));
    free(tmp);
}
static void save_net(Net *n,const char *path) {
    char *tmp=temp_path(path);FILE *f=open_file(tmp,"wb");write_bytes(f,"LTCKP001",8);config_write(f,n->c);
    put64(f,n->step);put64(f,n->rng.s);putfloat(f,n->temperature);putfloat(f,n->best_val);vocab_write(f,&n->vocab);
    param_write(f,n->emb);param_write(f,n->bias);
    for(int i=0;i<n->c.blocks+2;i++) {
        Layer *l=n->l+i;put32(f,l->C);put32(f,l->O);put32(f,l->d);put32(f,l->dilation);put32(f,l->kernel);
        for(int j=0;j<l->O*l->R;j++)put32(f,(uint32_t)l->ch[j]);
        for(int j=0;j<l->O*l->R;j++)put32(f,(uint32_t)l->off[j]);
        param_write(f,l->p);
    }finish_save(f,tmp,path);
}
static Net *load_net(const char *path) {
    FILE *f=open_file(path,"rb");char magic[8];read_bytes(f,magic,8);
    if(memcmp(magic,"LTCKP001",8))die("%s is not a training .ltc checkpoint",path);
    Config c=config_read(f);Net *n=net_new(c,1,0,1);n->step=get64(f);n->rng.s=get64(f);
    n->temperature=getfloat(f);n->best_val=getfloat(f);
    if(!n->rng.s || n->step>(uint64_t)c.steps || !(n->temperature>=.05f))die("invalid checkpoint state");
    n->vocab=vocab_read(f,c.vocab);param_read(f,&n->emb);param_read(f,&n->bias);
    for(int i=0;i<c.blocks+2;i++) {
        Layer *l=n->l+i;
        if(get32(f)!=(uint32_t)l->C || get32(f)!=(uint32_t)l->O || get32(f)!=(uint32_t)l->d ||
           get32(f)!=(uint32_t)l->dilation || get32(f)!=(uint32_t)l->kernel)die("checkpoint layer mismatch");
        for(int j=0;j<l->O*l->R;j++){uint32_t x=get32(f);if(x>=(uint32_t)l->C)die("channel out of bounds");l->ch[j]=(int32_t)x;}
        for(int j=0;j<l->O*l->R;j++){int32_t x=(int32_t)get32(f);if(x<-(l->kernel/2)||x>l->kernel/2)die("offset out of bounds");l->off[j]=x;}
        param_read(f,&l->p);
    }
    if(fgetc(f)!=EOF)die("trailing checkpoint bytes");
    fclose(f);refresh(n);return n;
}
static void reset_optimizer(Net *n) {
    n->step=0;n->best_val=-1;n->temperature=1;
    Param *a[MAX_BLOCKS+4];int k=0;a[k++]=&n->emb;a[k++]=&n->bias;
    for(int i=0;i<n->c.blocks+2;i++)a[k++]=&n->l[i].p;
    for(int i=0;i<k;i++){memset(a[i]->m,0,a[i]->n*4);memset(a[i]->v,0,a[i]->n*4);a[i]->t=0;}
}

/* ----------------------- float-free deployed model ----------------------- */
typedef struct {int C,O,d,dilation,kernel,R,N;int32_t *ch,*off;uint8_t *f;} HLayer;
typedef struct {Config c;uint64_t *codes;HLayer *l;Vocab vocab;} Hard;
static void hard_free(Hard *h) {
    if(!h)return;
    for(int i=0;i<h->c.blocks+1;i++){free(h->l[i].ch);free(h->l[i].off);free(h->l[i].f);}
    free(h->l);free(h->codes);vocab_free(&h->vocab);free(h);
}
static Hard *harden(Net *n) {
    Hard *h=alloc(1,sizeof *h);h->c=n->c;int Q=(n->c.bits+63)/64;
    h->codes=alloc(mul(n->c.vocab,Q),8);h->l=alloc(n->c.blocks+1,sizeof(HLayer));
    for(int v=1;v<n->c.vocab;v++)for(int k=0;k<n->c.bits;k++)
        if(sigmoid(n->emb.z[(size_t)v*n->c.bits+k]/fmaxf(.05f,n->temperature))>.5f)h->codes[(size_t)v*Q+k/64]|=UINT64_C(1)<<(k%64);
    for(int i=0;i<n->c.blocks+1;i++) {
        Layer *s=n->l+(i==n->c.blocks?i+1:i);HLayer *l=h->l+i;
        l->C=s->C;l->O=s->O;l->d=s->d;l->dilation=s->dilation;l->kernel=s->kernel;l->R=s->R;l->N=s->N;
        l->ch=alloc(mul(l->O,l->R),4);l->off=alloc(mul(l->O,l->R),4);l->f=alloc(mul(l->O,l->N),1);
        memcpy(l->ch,s->ch,(size_t)l->O*l->R*4);memcpy(l->off,s->off,(size_t)l->O*l->R*4);
        for(int j=0;j<l->O*l->N;j++)for(int k=0;k<4;k++)
            if(corner(s->p.z[4*j+k],n->c.est)>.5f)l->f[j]|=(uint8_t)(1u<<k);
    }
    h->vocab.n=n->vocab.n;h->vocab.words=alloc(h->vocab.n,sizeof(char*));
    for(int i=0;i<h->vocab.n;i++)h->vocab.words[i]=copystr(n->vocab.words[i]);
    vocab_index(&h->vocab);return h;
}
static void save_hard(Hard *h,const char *path) {
    char *tmp=temp_path(path);FILE *f=open_file(tmp,"wb");write_bytes(f,"LTHRD001",8);
    Config c=h->c;int a[]={c.vocab,c.bits,c.width,c.blocks,c.depth,c.kernel,c.cycle,c.votes,c.est,c.q8};
    for(int i=0;i<10;i++)put32(f,a[i]);
    vocab_write(f,&h->vocab);
    for(size_t i=0;i<(size_t)c.vocab*((c.bits+63)/64);i++)put64(f,h->codes[i]);
    for(int i=0;i<c.blocks+1;i++) {
        HLayer *l=h->l+i;put32(f,l->C);put32(f,l->O);put32(f,l->d);put32(f,l->dilation);put32(f,l->kernel);
        for(int j=0;j<l->O*l->R;j++)put32(f,(uint32_t)l->ch[j]);
        for(int j=0;j<l->O*l->R;j++)put32(f,(uint32_t)l->off[j]);
        write_bytes(f,l->f,(size_t)l->O*l->N);
    }finish_save(f,tmp,path);
}
static Hard *load_hard(const char *path) {
    FILE *f=open_file(path,"rb");char magic[8];read_bytes(f,magic,8);
    if(!memcmp(magic,"LTCKP001",8)) {fclose(f);Net *n=load_net(path);Hard *h=harden(n);net_free(n);return h;}
    if(memcmp(magic,"LTHRD001",8))die("not a .lth or .ltc checkpoint: %s",path);
    Hard *h=alloc(1,sizeof *h);Config c=defaults();
    int *a[]={&c.vocab,&c.bits,&c.width,&c.blocks,&c.depth,&c.kernel,&c.cycle,&c.votes,&c.est,&c.q8};
    for(int i=0;i<10;i++){uint32_t v=get32(f);if(v>INT_MAX)die("invalid hard config");*a[i]=(int)v;}validate(c);h->c=c;
    h->vocab=vocab_read(f,c.vocab);int Q=(c.bits+63)/64;h->codes=alloc(mul(c.vocab,Q),8);
    for(size_t i=0;i<(size_t)c.vocab*Q;i++)h->codes[i]=get64(f);
    for(int k=0;k<Q;k++)if(h->codes[k])die("PAD code must be all-zero");
    if(c.bits%64)for(int v=0;v<c.vocab;v++)if(h->codes[(size_t)v*Q+Q-1]>>(c.bits%64))die("codebook tail bits must be zero");
    h->l=alloc(c.blocks+1,sizeof(HLayer));
    for(int i=0;i<c.blocks+1;i++) {
        HLayer *l=h->l+i;l->C=(int)get32(f);l->O=(int)get32(f);l->d=(int)get32(f);l->dilation=(int)get32(f);l->kernel=(int)get32(f);
        int C=i?c.width:c.bits,O=i==c.blocks?2*c.votes:c.width,dilation=i==c.blocks?1:1<<(i%c.cycle),kernel=i==c.blocks?1:c.kernel;
        if(l->C!=C||l->O!=O||l->d!=c.depth||l->dilation!=dilation||l->kernel!=kernel)die("invalid hard layer");
        l->R=1<<l->d;l->N=l->R-1;l->ch=alloc(mul(l->O,l->R),4);l->off=alloc(mul(l->O,l->R),4);l->f=alloc(mul(l->O,l->N),1);
        for(int j=0;j<l->O*l->R;j++){uint32_t v=get32(f);if(v>=(uint32_t)C)die("invalid hard channel");l->ch[j]=(int32_t)v;}
        for(int j=0;j<l->O*l->R;j++){int32_t v=(int32_t)get32(f);if(v<-(kernel/2)||v>kernel/2)die("invalid hard offset");l->off[j]=v;}
        read_bytes(f,l->f,(size_t)l->O*l->N);
        for(int j=0;j<l->O*l->N;j++)if(l->f[j]>15)die("invalid truth table");
    }
    if(fgetc(f)!=EOF)die("trailing hard checkpoint bytes");
    fclose(f);return h;
}
typedef struct {int B,T,P,maxC;uint64_t *a,*b,*mask,*pmask;int64_t *scores;} HWork;
static HWork *hwork_new(Hard *h,int B,int T) {
    Config c=h->c;c.batch=B;c.seq=T;validate(c);
    HWork *w=alloc(1,sizeof *w);w->B=B;w->T=T;w->P=(B+63)/64;
    w->maxC=c.width>c.bits?c.width:c.bits;if(w->maxC<2*c.votes)w->maxC=2*c.votes;
    size_t n=mul(mul(w->P,T),w->maxC);w->a=alloc(n,8);w->b=alloc(n,8);
    w->mask=alloc(mul(w->P,T),8);w->pmask=alloc(mul(w->P,(T+1)/2),8);w->scores=alloc(mul(B,2),8);return w;
}
static void hwork_free(HWork *w) {free(w->a);free(w->b);free(w->mask);free(w->pmask);free(w->scores);free(w);}
static void hard_layer(const HLayer *l,const uint64_t *x,uint64_t *y,const uint64_t *mask,int P,int T) {
    #pragma omp parallel for collapse(2) schedule(static)
    for(int p=0;p<P;p++)for(int o=0;o<l->O;o++)for(int t=0;t<T;t++) {
        uint64_t v[2*MAX_LEAVES-1];
        for(int k=0;k<l->R;k++) {
            int s=t+l->off[o*l->R+k]*l->dilation;
            v[l->N+k]=(s<0||s>=T)?0:x[((size_t)p*T+s)*l->C+l->ch[o*l->R+k]];
        }
        for(int j=l->N-1;j>=0;j--)v[j]=gate64(v[2*j+1],v[2*j+2],l->f[o*l->N+j]);
        y[((size_t)p*T+t)*l->O+o]=v[0]&mask[(size_t)p*T+t];
    }
}
static void hard_predict(Hard *h,HWork *w,const uint32_t *ids) {
    int C=h->c.bits,T=w->T,Q=(C+63)/64,W=h->c.width,U=(T+1)/2;
    uint64_t *cur=w->a,*next=w->b;
    for(size_t i=0;i<(size_t)w->B*T;i++)if(ids[i]>=(uint32_t)h->c.vocab)die("inference token outside vocabulary");
    #pragma omp parallel for collapse(2) schedule(static)
    for(int p=0;p<w->P;p++)for(int t=0;t<T;t++) {
        uint64_t *row=cur+((size_t)p*T+t)*C;memset(row,0,C*8);uint64_t mask=0;
        for(int k=0;k<64 && p*64+k<w->B;k++) {
            uint32_t id=ids[(size_t)(p*64+k)*T+t];uint64_t bit=UINT64_C(1)<<k;
            if(id)mask|=bit;
            for(int q=0;q<Q;q++) {
                uint64_t code=h->codes[(size_t)id*Q+q];
                while(code){int b=lowbit(code);int c=q*64+b;if(c<C)row[c]|=bit;code&=code-1;}
            }
        }w->mask[(size_t)p*T+t]=mask;
    }
    for(int i=0;i<h->c.blocks;i++) {
        hard_layer(h->l+i,cur,next,w->mask,w->P,T);uint64_t *tmp=cur;cur=next;next=tmp;
    }
    #pragma omp parallel for collapse(2) schedule(static)
    for(int p=0;p<w->P;p++)for(int u=0;u<U;u++) {
        int t=2*u;w->pmask[(size_t)p*U+u]=w->mask[(size_t)p*T+t] | (t+1<T?w->mask[(size_t)p*T+t+1]:0);
        for(int c=0;c<W;c++)next[((size_t)p*U+u)*W+c]=cur[((size_t)p*T+t)*W+c] | (t+1<T?cur[((size_t)p*T+t+1)*W+c]:0);
    }
    {uint64_t *tmp=cur;cur=next;next=tmp;}
    hard_layer(h->l+h->c.blocks,cur,next,w->pmask,w->P,U);
    int votes=h->c.votes,O=2*votes,bits=0;uint64_t maxcount=(uint64_t)U*votes;
    do{bits++;maxcount>>=1;}while(maxcount);
    #pragma omp parallel for collapse(2) schedule(static)
    for(int p=0;p<w->P;p++)for(int cls=0;cls<2;cls++) {
        uint64_t cnt[32]={0};
        for(int t=0;t<U;t++)for(int v=0;v<votes;v++) {
            uint64_t carry=next[((size_t)p*U+t)*O+cls*votes+v];
            for(int j=0;j<bits && carry;j++){uint64_t tmp=cnt[j]&carry;cnt[j]^=carry;carry=tmp;}
        }
        for(int k=0;k<64 && p*64+k<w->B;k++) {
            int64_t s=0;for(int j=0;j<bits;j++)s|=(int64_t)((cnt[j]>>k)&1)<<j;
            w->scores[(size_t)(p*64+k)*2+cls]=s;
        }
    }
}

/* ------------------------------ data / text ------------------------------ */
static char *line_read(FILE *f) {
    size_t cap=256,n=0;char *s=alloc(cap,1);int c;
    while((c=fgetc(f))!=EOF && c!='\n') {
        if(c==0)die("NUL in text input");
        if(n>=MAX_RECORD)die("input line exceeds 64 MiB");
        if(n+1>=cap){cap*=2;s=resize(s,cap,1);}s[n++]=(char)c;
    }
    if(c==EOF && !n){free(s);return NULL;}if(n && s[n-1]=='\r')n--;s[n]=0;return s;
}
static char *trim(char *s) {
    while(*s==' '||*s=='\t'||*s=='\r'||*s=='\n')s++;
    size_t n=strlen(s);while(n && (s[n-1]==' '||s[n-1]=='\t'||s[n-1]=='\r'||s[n-1]=='\n'))s[--n]=0;return s;
}
static int parse_label(const char *s) {
    if(!strcmp(s,"0")||!strcmp(s,"negative"))return 0;
    if(!strcmp(s,"1")||!strcmp(s,"positive"))return 1;
    if(!strcmp(s,"-1")||!*s)return -1;
    die("invalid label '%s'",s);return -1;
}
static Vocab vocab_text(const char *path,int V) {
    Vocab v={0};v.words=alloc(V,sizeof(char*));FILE *f=open_file(path,"rb");char *s;
    while((s=line_read(f))) {
        if(v.n==V)die("vocabulary exceeds --vocab-size");
        if(!*s)die("blank vocabulary entry");
        v.words[v.n++]=s;
    }fclose(f);
    if(v.n<3 || strcmp(v.words[0],"[PAD]") || strcmp(v.words[1],"[MASK]") || strcmp(v.words[2],"[UNK]"))
        die("vocabulary must start with [PAD], [MASK], [UNK]");
    vocab_index(&v);return v;
}
static int ascii_letter(int c) {return c>='a'&&c<='z';}
static int ascii_word(int c) {return ascii_letter(c)||(c>='0'&&c<='9');}
static char *normalize_text(const char *text) {
    size_t n=strlen(text);char *s=alloc(n+1,1);size_t w=0;
    for(size_t i=0;i<n;) {
        unsigned char c=(unsigned char)text[i++];
        if(c=='<') {const char *end=strchr(text+i,'>');if(end){i=(size_t)(end-text)+1;s[w++]=' ';continue;}}
        if(c=='&') {
            const char *end=strchr(text+i,';');
            if(end && end-(text+i)<16) {
                size_t len=(size_t)(end-(text+i));char buf[20];memcpy(buf,text+i,len);buf[len]=0;int decoded=-1;
                if(!strcmp(buf,"amp"))decoded='&';else if(!strcmp(buf,"lt"))decoded='<';else if(!strcmp(buf,"gt"))decoded='>';
                else if(!strcmp(buf,"quot"))decoded='"';else if(!strcmp(buf,"apos")||!strcmp(buf,"#39"))decoded='\'';
                else if(!strcmp(buf,"nbsp"))decoded=' ';
                else if(buf[0]=='#') {char *e;int hex=buf[1]=='x'||buf[1]=='X';long val=strtol(buf+1+hex,&e,hex?16:10);if(!*e && val>0 && val<128)decoded=(int)val;}
                if(decoded>=0){c=(unsigned char)decoded;i=(size_t)(end-text)+1;}
            }
        }
        if(c>='A'&&c<='Z')c=(unsigned char)(c+'a'-'A');
        s[w++]=(char)c;
    }s[w]=0;return s;
}
typedef void (*WordFn)(const char *,void *);
static void tokenize(const char *text,int limit,WordFn fn,void *ctx) {
    char *s=normalize_text(text);size_t i=0;int n=0;
    while(s[i] && n<limit) {
        size_t start=i;
        if(ascii_word((unsigned char)s[i])) {
            while(ascii_word((unsigned char)s[i]))i++;
            if(s[i]=='\'' && ascii_letter((unsigned char)s[i+1])) {i++;while(ascii_letter((unsigned char)s[i]))i++;}
        } else if(strchr("!?.,;:",s[i]))i++;
        else{i++;continue;}
        char end=s[i];s[i]=0;fn(s+start,ctx);s[i]=end;n++;
    }free(s);
}
static char **csv_row(FILE *f,int *ncol) {
    char **cols=alloc(64,sizeof(char*));size_t cap=256,n=0,total=0;char *s=alloc(cap,1);
    int quoted=0,at_start=1,after_quote=0,c,any=0;*ncol=0;
    for(;;) {
        c=fgetc(f);
        if(c==EOF && !any){free(s);free(cols);return NULL;}any=1;
        if(c==0)die("NUL in CSV");
        if(quoted) {
            if(c==EOF)die("unclosed CSV quote");
            if(c=='"') {int d=fgetc(f);if(d=='"')c='"';else{quoted=0;after_quote=1;if(d!=EOF)ungetc(d,f);continue;}}
        } else {
            if(at_start && c=='"'){quoted=1;at_start=0;continue;}
            if(c==','||c=='\n'||c=='\r'||c==EOF) {
                if(*ncol==64)die("CSV has more than 64 columns");
                s[n]=0;cols[(*ncol)++]=s;
                if(c!=',') {if(c=='\r'){int d=fgetc(f);if(d!=EOF && d!='\n')ungetc(d,f);}return cols;}
                cap=256;n=0;s=alloc(cap,1);at_start=1;after_quote=0;continue;
            }
            if(after_quote){if(c==' '||c=='\t')continue;die("characters after CSV closing quote");}
        }
        if(++total>MAX_RECORD)die("CSV record exceeds 64 MiB");
        if(n+1>=cap){cap*=2;s=resize(s,cap,1);}s[n++]=(char)c;at_start=0;
    }
}
static void csv_free(char **a,int n){for(int i=0;i<n;i++)free(a[i]);free(a);}
typedef void (*RecordFn)(int,const char *,void *);
static void text_records(const char *path,const char *fmt,RecordFn fn,void *ctx) {
    FILE *f=open_file(path,"rb");
    unsigned char bom[3];size_t got=fread(bom,1,3,f);if(got!=3||memcmp(bom,"\xef\xbb\xbf",3))rewind(f);
    if(!strcmp(fmt,"csv")) {
        int nc;char **header=csv_row(f,&nc);if(!header)die("empty CSV");int ti=-1,li=-1;
        for(int i=0;i<nc;i++){char *s=trim(header[i]);if(!strcmp(s,"review")||!strcmp(s,"text"))ti=i;if(!strcmp(s,"sentiment")||!strcmp(s,"label"))li=i;}
        if(ti<0)die("CSV needs a review or text header");
        csv_free(header,nc);
        char **row;
        while((row=csv_row(f,&nc))) {
            if(nc==1 && !*row[0]){csv_free(row,nc);continue;}
            if(ti>=nc||li>=nc)die("CSV row has missing columns");
            int label=li<0?-1:parse_label(trim(row[li]));fn(label,row[ti],ctx);csv_free(row,nc);
        }
    } else if(!strcmp(fmt,"tsv")||!strcmp(fmt,"text")) {
        char *s;while((s=line_read(f))) {
            if(!*s){free(s);continue;}int label=-1;char *text=s;
            if(!strcmp(fmt,"tsv")){char *tab=strchr(s,'\t');if(!tab)die("TSV expects label<TAB>text");*tab=0;label=parse_label(trim(s));text=tab+1;}
            fn(label,text,ctx);free(s);
        }
    }else die("unsupported text format: %s",fmt);
    if(ferror(f))die("read failed: %s",path);
    fclose(f);
}
typedef struct {int n,cap,T,V;uint32_t *x;int *y;const Vocab *vocab;} Data;
static void data_reserve(Data *d) {
    if(d->n<d->cap)return;
    int old=d->cap;
    if(old>INT_MAX/2)die("too many records");
    d->cap=old?old*2:128;
    d->x=resize(d->x,mul(d->cap,d->T),4);d->y=resize(d->y,d->cap,sizeof(int));
}
typedef struct {const Vocab *v;uint32_t *out;int n;} EncodeCtx;
static void encode_word(const char *s,void *ctx) {EncodeCtx *a=ctx;a->out[a->n++]=(uint32_t)vocab_lookup(a->v,s);}
static void data_text_record(int label,const char *s,void *ctx) {
    Data *d=ctx;data_reserve(d);uint32_t *x=d->x+(size_t)d->n*d->T;memset(x,0,d->T*4);
    EncodeCtx a={d->vocab,x,0};tokenize(s,d->T,encode_word,&a);d->y[d->n++]=label;
}
static long parse_long(const char *s,long lo,long hi) {
    char *e;errno=0;long v=strtol(s,&e,10);if(errno||!*s||*e||v<lo||v>hi)die("invalid integer: %s",s);return v;
}
static float parse_float(const char *s) {
    char *e;errno=0;float v=strtof(s,&e);if(errno||!*s||*e||!isfinite(v))die("invalid float: %s",s);return v;
}
static Data data_load(const char *path,const char *fmt,const Vocab *v,int V,int T) {
    Data d={0};d.T=T;d.V=V;d.vocab=v;
    if(!strcmp(fmt,"ids")) {
        FILE *f=open_file(path,"rb");char *s;
        while((s=line_read(f))) {
            char *p=trim(s);if(!*p){free(s);continue;}
            data_reserve(&d);uint32_t *x=d.x+(size_t)d.n*T;memset(x,0,T*4);
            char *e=p;errno=0;long lab=strtol(p,&e,10);if(errno||e==p||lab< -1||lab>1||(*e && *e!=' ' && *e!='\t'))die("IDS line needs label -1, 0 or 1");
            p=e;int k=0;
            while(*p) {
                while(*p==' '||*p=='\t')p++;
                if(!*p)break;
                if(*p<'0'||*p>'9')die("IDS tokens must be unsigned integers");
                errno=0;unsigned long id=strtoul(p,&e,10);
                if(errno||id>=(unsigned long)V||(*e && *e!=' ' && *e!='\t'))die("invalid token ID");
                if(k<T)x[k++]=(uint32_t)id;
                p=e;
            }
            d.y[d.n++]=(int)lab;free(s);
        }if(ferror(f))die("read failed: %s",path);fclose(f);
    } else {
        if(!v || !v->n)die("text input requires --vocab or vocabulary embedded in checkpoint");
        text_records(path,fmt,data_text_record,&d);
    }
    if(!d.n)die("dataset is empty: %s",path);
    return d;
}
static void data_free(Data *d){free(d->x);free(d->y);memset(d,0,sizeof *d);}
static void require_labels(Data *d){for(int i=0;i<d->n;i++)if(d->y[i]<0)die("supervised dataset contains an unlabeled record");}
typedef struct {Vocab v;uint64_t *count;int capacity,limit;} BuildVocab;
static void count_word(const char *s,void *ctx) {
    BuildVocab *b=ctx;int id=vocab_lookup(&b->v,s);
    if(id!=UNK){b->count[id]++;return;}
    if(b->v.n==b->capacity) {
        b->capacity*=2;b->v.words=resize(b->v.words,b->capacity,sizeof(char*));b->count=resize(b->count,b->capacity,8);
    }
    id=b->v.n++;b->v.words[id]=copystr(s);b->count[id]=1;
    if((size_t)b->v.n*2>b->v.cap){vocab_index(&b->v);return;}
    size_t i=hashword(s)&(b->v.cap-1);while(b->v.slot[i])i=(i+1)&(b->v.cap-1);b->v.slot[i]=id+1;
}
static void count_record(int label,const char *s,void *ctx){(void)label;BuildVocab *b=ctx;tokenize(s,b->limit,count_word,b);}
typedef struct {char *s;uint64_t n;} WordCount;
static int wordcmp(const void *a,const void *b) {
    const WordCount *x=a,*y=b;if(x->n!=y->n)return x->n>y->n?-1:1;return strcmp(x->s,y->s);
}
static void make_vocab(const char *data,const char *fmt,const char *out,int V,int T) {
    BuildVocab b={0};b.capacity=128;b.limit=T;b.v.n=3;b.v.words=alloc(b.capacity,sizeof(char*));b.count=alloc(b.capacity,8);
    b.v.words[0]=copystr("[PAD]");b.v.words[1]=copystr("[MASK]");b.v.words[2]=copystr("[UNK]");vocab_index(&b.v);
    text_records(data,fmt,count_record,&b);int words=b.v.n-3;
    WordCount *a=alloc(words,sizeof *a);for(int i=0;i<words;i++)a[i]=(WordCount){b.v.words[i+3],b.count[i+3]};qsort(a,words,sizeof *a,wordcmp);
    FILE *f=open_file(out,"wb");fputs("[PAD]\n[MASK]\n[UNK]\n",f);int kept=words<V-3?words:V-3;
    for(int i=0;i<kept;i++)fprintf(f,"%s\n",a[i].s);
    for(int i=kept+3;i<V;i++)fprintf(f,"[UNUSED_%d]\n",i);
    if(ferror(f)||fclose(f))die("vocabulary write failed");
    fprintf(stderr,"vocabulary: %d observed, %d retained, capacity %d -> %s\n",words,kept,V,out);
    free(a);free(b.count);vocab_free(&b.v);
}

/* --------------------------- training / evaluation ----------------------- */
static double eval_hard(Hard *h,Data *d,int B,int predictions) {
    HWork *w=hwork_new(h,B,d->T);uint32_t *tail=alloc(mul(B,d->T),4);int hit=0,labeled=0;
    for(int i=0;i<d->n;i+=B) {
        int take=d->n-i<B?d->n-i:B;const uint32_t *x=d->x+(size_t)i*d->T;
        if(take<B){memset(tail,0,(size_t)B*d->T*4);memcpy(tail,x,(size_t)take*d->T*4);x=tail;}
        hard_predict(h,w,x);
        for(int j=0;j<take;j++) {
            int pred=w->scores[2*j+1]>w->scores[2*j];
            if(d->y[i+j]>=0){labeled++;hit+=pred==d->y[i+j];}
            if(predictions)printf("{\"row\":%d,\"label\":%d,\"votes\":[%lld,%lld]}\n",i+j,pred,(long long)w->scores[2*j],(long long)w->scores[2*j+1]);
        }
    }
    hwork_free(w);free(tail);
    if(predictions)fprintf(stderr,"labeled=%d correct=%d accuracy=%.6f\n",labeled,hit,labeled?(double)hit/labeled:0.);
    return labeled?(double)hit/labeled:-1.;
}
static double eval_mlm(Net *n,Data *d) {
    RNG saved=n->rng;n->rng.s=UINT64_C(730921);double total=0;long nt=0;int B=n->c.batch;
    Work *w=work_new(n,B,d->T);
    for(int i=0;i<d->n;i+=B) {
        int take=d->n-i<B?d->n-i:B;Work *v=take==B?w:work_new(n,take,d->T);
        memcpy(v->ids,d->x+(size_t)i*d->T,(size_t)take*d->T*4);int nm=corrupt(n,v);
        total+=masked_loss(n,v,0)*nm;nt+=nm;if(v!=w)work_free(v,n->c.blocks);
    }work_free(w,n->c.blocks);n->rng=saved;return total/nt;
}
static size_t parameter_count(Net *n) {
    size_t p=n->emb.n+n->bias.n;for(int i=0;i<n->c.blocks+2;i++)p+=n->l[i].p.n;return p;
}
static char *suffix(const char *s,const char *tail) {char *out=alloc(strlen(s)+strlen(tail)+1,1);strcpy(out,s);strcat(out,tail);return out;}
static void export_net(Net *n,const char *path){Hard *h=harden(n);save_hard(h,path);hard_free(h);}
static void train_net(Net *n,Data *d,Data *val,const char *save,const char *export_path,int stop,int every) {
    if(!n->c.stage)require_labels(d);
    if(val && !n->c.stage)require_labels(val);
    Work *w=work_new(n,n->c.batch,n->c.seq);double start=now(),compute=0;float lastce=0;
    uint64_t end=stop>0?(uint64_t)stop:(uint64_t)n->c.steps;if(end>(uint64_t)n->c.steps)end=n->c.steps;
    if(end<=n->step)die("stop point must be later than checkpoint step (%llu)",(unsigned long long)n->step);
    fprintf(stderr,"%s: records=%d params=%zu bits=%d width=%d blocks=%d batch=%d seq=%d threads=%d\n",
            n->c.stage?"MLM":"supervised",d->n,parameter_count(n),n->c.bits,n->c.width,n->c.blocks,w->B,w->T,thread_count());
    for(;n->step<end;) {
        double t=now();float progress=n->c.steps>1?(float)n->step/(n->c.steps-1):0;
        float lr=n->c.peak_lr*(.1f+.9f*.5f*(1.f+cosf((float)PI*progress)));
        n->temperature=1.f-.8f*fminf(1.f,progress/.8f);
        for(int b=0;b<w->B;b++) {
            int i=randint(&n->rng,d->n);memcpy(w->ids+(size_t)b*w->T,d->x+(size_t)i*d->T,w->T*4);w->labels[b]=d->y[i];
        }
        int targets=n->c.stage?corrupt(n,w):0;
        float loss=objective(n,w,n->c.sharp*progress,1,&lastce);
        if(!isfinite(loss))die("nonfinite training loss");
        adam(n,lr);n->step++;compute+=now()-t;
        if(n->step%(uint64_t)every==0 || n->step==end) {
            double metric=-1;int best=0;
            if(val) {
                if(n->c.stage)metric=-eval_mlm(n,val);
                else{Hard *h=harden(n);metric=eval_hard(h,val,n->c.batch,0);hard_free(h);}
                if((n->c.stage && (n->best_val==-1 || metric>n->best_val)) || (!n->c.stage && metric>n->best_val)) {
                    n->best_val=(float)metric;best=1;
                }
            }
            save_net(n,save);
            if(best) {
                char *p=suffix(save,".best");save_net(n,p);free(p);
                if(export_path){p=suffix(export_path,".best");export_net(n,p);free(p);}
            }
            fprintf(stderr,"{\"step\":%llu,\"ce\":%.7g,\"loss\":%.7g,\"lr\":%.7g,\"code_temperature\":%.5g,\"masked_targets\":%d,\"compute_seconds\":%.4f,\"wall_seconds\":%.4f",
                    (unsigned long long)n->step,lastce,loss,lr,n->temperature,targets,compute,now()-start);
            if(val)fprintf(stderr,n->c.stage?",\"val_mlm_ce\":%.7g":",\"val_hard_accuracy\":%.7g",n->c.stage?-metric:metric);
            fputs("}\n",stderr);fflush(stderr);
        }
    }
    if(export_path)export_net(n,export_path);
    work_free(w,n->c.blocks);
}
static int doublecmp(const void *a,const void *b){double x=*(const double*)a,y=*(const double*)b;return (x>y)-(x<y);}
static void bench(Hard *h,Data *d,int B,int repeats,int warmup) {
    HWork *w=hwork_new(h,B,d->T);uint32_t *x=alloc(mul(B,d->T),4);
    double *times=alloc(repeats,sizeof(double));volatile uint64_t checksum=0;long occupied=0;
    for(int b=0;b<B;b++)for(int t=0;t<d->T;t++) {uint32_t id=d->x[(size_t)(b%d->n)*d->T+t];x[(size_t)b*d->T+t]=id;occupied+=id!=0;}
    for(int r=-warmup;r<repeats;r++) {
        double t=now();hard_predict(h,w,x);
        for(int b=0;b<B;b++)checksum+=(uint64_t)w->scores[2*b]+(uint64_t)w->scores[2*b+1]+(w->scores[2*b+1]>w->scores[2*b]);
        double elapsed=now()-t;if(r>=0)times[r]=elapsed;
    }
    qsort(times,repeats,sizeof(double),doublecmp);double med=times[repeats/2];if(!(repeats%2))med=(med+times[repeats/2-1])*.5;
    printf("{\"batch\":%d,\"sequence_length\":%d,\"threads\":%d,\"median_batch_ms\":%.6f,\"reviews_per_second\":%.3f,\"positions_per_second\":%.3f,\"mean_nonpadding\":%.3f,\"source_records\":%d,\"repeats\":%d,\"checksum\":%llu,\"includes\":\"lookup,packing,gates,OR,integer_counts,argmax\",\"excludes\":\"tokenization,IO,load,workspace_allocation\"}\n",
           B,d->T,thread_count(),med*1000,B/med,(double)B*d->T/med,(double)occupied/B,d->n,repeats,(unsigned long long)checksum);
    free(times);free(x);hwork_free(w);
}

/* ---------------------- independent executable checks -------------------- */
static void scalar_hard(Hard *h,const uint32_t *ids,int B,int T,int64_t *scores) {
    int maxC=h->c.bits;if(maxC<h->c.width)maxC=h->c.width;if(maxC<2*h->c.votes)maxC=2*h->c.votes;
    uint8_t *a=alloc(mul(T,maxC),1),*b=alloc(mul(T,maxC),1);int Q=(h->c.bits+63)/64;
    for(int sample=0;sample<B;sample++) {
        int length=T,C=h->c.bits;uint8_t *cur=a,*nxt=b;
        for(int t=0;t<T;t++)for(int c=0;c<C;c++)cur[t*C+c]=(uint8_t)((h->codes[(size_t)ids[(size_t)sample*T+t]*Q+c/64]>>(c%64))&1);
        for(int i=0;i<=h->c.blocks;i++) {
            if(i==h->c.blocks) {
                int U=(T+1)/2;for(int u=0;u<U;u++)for(int c=0;c<C;c++)nxt[u*C+c]=cur[2*u*C+c] | (2*u+1<T?cur[(2*u+1)*C+c]:0);
                uint8_t *z=cur;cur=nxt;nxt=z;length=U;
            }
            HLayer *l=h->l+i;
            for(int t=0;t<length;t++)for(int o=0;o<l->O;o++) {
                uint8_t v[2*MAX_LEAVES-1];
                for(int k=0;k<l->R;k++){int s=t+l->off[o*l->R+k]*l->dilation;v[l->N+k]=(s<0||s>=length)?0:cur[s*C+l->ch[o*l->R+k]];}
                for(int j=l->N-1;j>=0;j--)v[j]=(uint8_t)((l->f[o*l->N+j]>>(2*v[2*j+1]+v[2*j+2]))&1);
                int valid=i==h->c.blocks?(ids[(size_t)sample*T+2*t]!=0 || (2*t+1<T && ids[(size_t)sample*T+2*t+1]!=0)):ids[(size_t)sample*T+t]!=0;
                nxt[t*l->O+o]=v[0] & valid;
            }
            uint8_t *z=cur;cur=nxt;nxt=z;C=l->O;
        }
        scores[2*sample]=scores[2*sample+1]=0;
        for(int t=0;t<length;t++)for(int o=0;o<C;o++)scores[2*sample+o/h->c.votes]+=cur[t*C+o];
    }free(a);free(b);
}
static void selftest(void) {
    for(int f=0;f<16;f++)for(int a=0;a<2;a++)for(int b=0;b<2;b++) {
        float p[4];for(int k=0;k<4;k++)p[k]=(float)((f>>k)&1);
        int expect=(f>>(2*a+b))&1;
        if(gate((float)a,(float)b,p)!=expect || (gate64(-(uint64_t)a,-(uint64_t)b,(uint8_t)f)&1)!=(uint64_t)expect)die("truth-table selftest failed");
    }
    Config c=defaults();c.vocab=16;c.bits=8;c.width=12;c.blocks=2;c.depth=2;c.cycle=2;c.votes=8;c.batch=4;c.seq=7;c.steps=80;
    Net *n=net_new(c,1,1,42);Work *w=work_new(n,4,7);RNG r={139};
    for(int i=0;i<28;i++){w->ids[i]=(uint32_t)(3+randint(&r,13));if(i%7>4)w->ids[i]=0;w->targets[i]=w->ids[i];w->selected[i]=i%7==2;}
    for(int i=0;i<4;i++)w->labels[i]=i%2;
    for(size_t i=c.bits;i<n->emb.n;i++)n->emb.z[i]+=.37f*normal(&r);
    for(int est=0;est<2;est++) {
        n->c.est=est;
        if(est)for(int l=0;l<n->c.blocks+2;l++)for(size_t k=0;k<n->l[l].p.n;k++)n->l[l].p.z[k]*=.4f;
        for(int stage=0;stage<2;stage++) {
            n->c.stage=stage;float ce;objective(n,w,.002f,1,&ce);Param *pp[MAX_BLOCKS+3];int np=active_params(n,pp);
            float worst=0,max_abs=0;
            for(int i=0;i<48;i++) {
                Param *p=pp[i%np];size_t j=(size_t)randint(&r,(int)p->n);float old=p->z[j],an=p->g[j],eps=.005f;
                p->z[j]=old+eps;float plus=objective(n,w,.002f,0,&ce);
                p->z[j]=old-eps;float minus=objective(n,w,.002f,0,&ce);p->z[j]=old;
                float num=(plus-minus)/(2*eps),abs=fabsf(an-num),rel=abs/fmaxf(.0005f,fabsf(an)+fabsf(num));
                if(rel>worst)worst=rel;
                if(abs>max_abs)max_abs=abs;
            }
            if(worst>.035f || max_abs>.0002f)die("gradient selftest failed: est=%d stage=%d rel=%g abs=%g",est,stage,worst,max_abs);
            printf("{\"check\":\"finite_difference\",\"estimator\":%d,\"stage\":%d,\"max_relative\":%.8g,\"max_absolute\":%.8g}\n",est,stage,worst,max_abs);
        }
    }
    n->c.stage=0;Hard *h=harden(n);int batches[]={1,4,65,128},lengths[]={1,7,32};
    for(int i=0;i<4;i++)for(int j=0;j<3;j++) {
        int B=batches[i],T=lengths[j];uint32_t *ids=alloc(mul(B,T),4);int64_t *ref=alloc(mul(B,2),8);HWork *hw=hwork_new(h,B,T);
        for(int b=0;b<B;b++)for(int t=0;t<T;t++)ids[(size_t)b*T+t]=(b%5 && t%7<5)?3+randint(&r,13):0;
        hard_predict(h,hw,ids);scalar_hard(h,ids,B,T,ref);
        if(memcmp(hw->scores,ref,(size_t)B*2*8))die("packed/scalar mismatch B=%d T=%d",B,T);
        free(ids);free(ref);hwork_free(hw);
    }
    char path[160],hp[160];unsigned long long tag=(unsigned long long)ru(&r)^(unsigned long long)(now()*1e9);
    snprintf(path,sizeof path,".logic_text_selftest_%llu.ltc",tag);snprintf(hp,sizeof hp,".logic_text_selftest_%llu.lth",tag);
    save_net(n,path);save_hard(h,hp);Net *copy=load_net(path);Hard *hc=load_hard(hp);
    if(memcmp(copy->emb.z,n->emb.z,n->emb.n*4))die("training checkpoint roundtrip failed");
    HWork *u=hwork_new(h,4,7),*v=hwork_new(hc,4,7);hard_predict(h,u,w->ids);hard_predict(hc,v,w->ids);
    if(memcmp(u->scores,v->scores,8*8))die("hard checkpoint roundtrip failed");
    hwork_free(u);hwork_free(v);hard_free(h);hard_free(hc);net_free(copy);remove(path);remove(hp);
    work_free(w,n->c.blocks);net_free(n);
    puts("{\"check\":\"truth_tables,packed_scalar,odd_padding,partial_packs,checkpoint_roundtrip\",\"passed\":true}");
}

/* --------------------------------- CLI ---------------------------------- */
typedef struct {
    Config c;uint64_t changed;
    const char *data,*val,*format,*vocab,*load,*resume,*save,*export_path,*out,*text;
    int threads,stop,every,repeats,warmup;uint64_t seed;int seed_set;
} Options;
static void usage(void) {
    puts("logic_text: standalone C learned-code convolutional logic network\n"
         "Commands: selftest | vocab | train | pretrain | export | predict | eval | bench | info");
}
static Options parse_options(int argc,char **argv) {
    Options o={0};o.c=defaults();o.threads=1;o.every=100;o.repeats=40;o.warmup=5;o.seed=17;o.format="ids";
    for(int i=2;i<argc;i++) {
        const char *key=argv[i];
        if(!strcmp(key,"--q8")){o.c.q8=1;o.changed|=UINT64_C(1)<<9;continue;}
        if(!strcmp(key,"--help")){usage();exit(0);}
        if(i+1>=argc)die("missing value for %s",key);
        const char *s=argv[++i];
#define SI(name,field,bit,lo,hi) if(!strcmp(key,name)){o.c.field=(int)parse_long(s,lo,hi);o.changed|=UINT64_C(1)<<bit;continue;}
#define SF(name,field,bit) if(!strcmp(key,name)){o.c.field=parse_float(s);o.changed|=UINT64_C(1)<<bit;continue;}
#define SP(name,field) if(!strcmp(key,name)){o.field=s;continue;}
#define SO(name,field,lo,hi) if(!strcmp(key,name)){o.field=(int)parse_long(s,lo,hi);continue;}
        SI("--vocab-size",vocab,0,4,1000000) SI("--code-bits",bits,1,2,1024) SI("--width",width,2,1,65536)
        SI("--blocks",blocks,3,1,MAX_BLOCKS) SI("--depth",depth,4,1,MAX_DEPTH) SI("--kernel",kernel,5,1,31)
        SI("--cycle",cycle,6,1,20) SI("--votes",votes,7,1,32768) SI("--seq",seq,10,1,65536)
        SI("--batch",batch,11,1,65536) SI("--steps",steps,12,1,1000000000) SI("--mlm-targets",max_targets,14,0,INT_MAX)
        SF("--lr",peak_lr,15) SF("--sharp",sharp,16) SF("--clip",clip,17) SF("--mask-prob",mask_prob,18)
        SF("--scale",scale,19) SF("--mlm-scale",mlm_scale,20)
        SP("--data",data) SP("--val",val) SP("--format",format) SP("--vocab",vocab) SP("--load",load)
        SP("--resume",resume) SP("--save",save) SP("--export",export_path) SP("--out",out) SP("--text",text)
        SO("--threads",threads,1,1024) SO("--eval-every",every,1,1000000000) SO("--stop-after",stop,1,1000000000)
        SO("--repeats",repeats,1,1000000) SO("--warmup",warmup,0,1000000)
        if(!strcmp(key,"--seed")){o.seed=(uint64_t)parse_long(s,1,LONG_MAX);o.seed_set=1;continue;}
        if(!strcmp(key,"--estimator")) {
            if(strcmp(s,"sigmoid")&&strcmp(s,"sin"))die("estimator must be sigmoid or sin");
            o.c.est=!strcmp(s,"sin");o.changed|=UINT64_C(1)<<8;continue;
        }
        die("unknown option %s",key);
#undef SI
#undef SF
#undef SP
#undef SO
    }
    if(o.load && o.resume)die("use either --load or --resume, not both");
    validate(o.c);return o;
}
static void overlay(Net *n,Options *o,int resume) {
    Config *c=&n->c,*s=&o->c;
    int *a[]={&c->vocab,&c->bits,&c->width,&c->blocks,&c->depth,&c->kernel,&c->cycle,&c->votes,&c->est,&c->q8,&c->seq,&c->batch,&c->steps,&c->stage,&c->max_targets};
    int b[]={s->vocab,s->bits,s->width,s->blocks,s->depth,s->kernel,s->cycle,s->votes,s->est,s->q8,s->seq,s->batch,s->steps,s->stage,s->max_targets};
    float *af[]={&c->peak_lr,&c->sharp,&c->clip,&c->mask_prob,&c->scale,&c->mlm_scale};
    float bf[]={s->peak_lr,s->sharp,s->clip,s->mask_prob,s->scale,s->mlm_scale};
    for(int i=0;i<15;i++)if(o->changed&(UINT64_C(1)<<i)) {
        if((resume||i<10) && *a[i]!=b[i])die("checkpoint architecture/schedule mismatch for option %d",i);
        *a[i]=b[i];
    }
    for(int i=0;i<6;i++)if(o->changed&(UINT64_C(1)<<(i+15))) {
        if(resume && *af[i]!=bf[i])die("resume cannot change schedule; use --load instead");
        *af[i]=bf[i];
    }
    validate(*c);
}
#ifndef LOGIC_NO_MAIN
int main(int argc,char **argv) {
    if(sizeof(float)!=4 || FLT_RADIX!=2 || FLT_MANT_DIG!=24)die("requires IEEE-754 binary32 floats");
    if(argc<2 || !strcmp(argv[1],"--help") || !strcmp(argv[1],"help")){usage();return 0;}
    Options o=parse_options(argc,argv);threads_set(o.threads);const char *cmd=argv[1];
    if(!strcmp(cmd,"selftest")){selftest();return 0;}
    if(!strcmp(cmd,"vocab")) {
        if(!o.data||!o.out)die("vocab requires --data and --out");
        make_vocab(o.data,o.format,o.out,o.c.vocab,o.c.seq);return 0;
    }
    if(!strcmp(cmd,"train")||!strcmp(cmd,"pretrain")) {
        if(!o.data||!o.save)die("training requires --data and --save");
        int stage=!strcmp(cmd,"pretrain");Net *n;
        if(o.resume||o.load) {
            n=load_net(o.resume?o.resume:o.load);overlay(n,&o,o.resume!=NULL);
            if(o.resume){if(n->c.stage!=stage || o.seed_set)die("resume preserves stage and RNG; use --load for a new run");}
            else{reset_optimizer(n);n->c.stage=stage;n->rng.s=o.seed;}
        }else{n=net_new(o.c,1,1,o.seed);n->c.stage=stage;}
        if(o.vocab) {
            Vocab v=vocab_text(o.vocab,n->c.vocab);
            if(n->vocab.n){if(n->vocab.n!=v.n)die("checkpoint vocabulary mismatch");for(int i=0;i<v.n;i++)if(strcmp(v.words[i],n->vocab.words[i]))die("checkpoint vocabulary mismatch");vocab_free(&v);}
            else n->vocab=v;
        }
        Data d=data_load(o.data,o.format,&n->vocab,n->c.vocab,n->c.seq),val={0};
        if(o.val)val=data_load(o.val,o.format,&n->vocab,n->c.vocab,n->c.seq);
        train_net(n,&d,o.val?&val:NULL,o.save,o.export_path,o.stop,o.every);
        data_free(&d);data_free(&val);net_free(n);return 0;
    }
    if(!strcmp(cmd,"export")) {
        if(!o.load||!o.out)die("export needs --load and --out");
        Hard *h=load_hard(o.load);save_hard(h,o.out);hard_free(h);return 0;
    }
    if(!strcmp(cmd,"predict")||!strcmp(cmd,"eval")||!strcmp(cmd,"bench")||!strcmp(cmd,"info")) {
        if(!o.load)die("--load is required");
        Hard *h=load_hard(o.load);
        if(o.vocab && !h->vocab.n)h->vocab=vocab_text(o.vocab,h->c.vocab);
        if(!strcmp(cmd,"info")) {
            size_t gates=0;for(int i=0;i<=h->c.blocks;i++)gates+=(size_t)h->l[i].O*h->l[i].N;
            printf("{\"vocab_size\":%d,\"code_bits\":%d,\"width\":%d,\"blocks\":%d,\"tree_depth\":%d,\"votes_per_class\":%d,\"deployed_gate_parameters\":%zu,\"has_vocabulary\":%s}\n",
                   h->c.vocab,h->c.bits,h->c.width,h->c.blocks,h->c.depth,h->c.votes,gates,h->vocab.n?"true":"false");hard_free(h);return 0;
        }
        Data d={0};
        if(o.text) {
            if(!h->vocab.n)die("--text needs an embedded vocabulary");
            d.T=o.c.seq;d.V=h->c.vocab;d.vocab=&h->vocab;data_text_record(-1,o.text,&d);
        }else {if(!o.data)die("--data or --text is required");d=data_load(o.data,o.format,&h->vocab,h->c.vocab,o.c.seq);}
        if(!strcmp(cmd,"bench"))bench(h,&d,o.c.batch,o.repeats,o.warmup);
        else if(!strcmp(cmd,"eval")){require_labels(&d);double acc=eval_hard(h,&d,o.c.batch,0);printf("{\"records\":%d,\"hard_accuracy\":%.8f}\n",d.n,acc);}
        else eval_hard(h,&d,o.text?1:o.c.batch,1);
        data_free(&d);hard_free(h);return 0;
    }
    die("unknown command: %s",cmd);return 1;
}
#endif
