#!/usr/bin/env python3
"""TF-IDF + logistic-regression ablation on the IMDB splits (see RESULTS.md, section 5).
usage: lexical_ablation.py DATA_DIR VOCAB.txt [a|b]
  a: vocab cap and truncation   b: bigrams and char 3-6-grams (slower, ~3 min)"""
import re, sys, time, numpy as np, scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
D, VOC, which = sys.argv[1], sys.argv[2], (sys.argv[3] if len(sys.argv) > 3 else 'a')
vset = set([l.rstrip("\n") for l in open(VOC)][3:])
tok = re.compile(r"[a-z0-9]+(?:'[a-z]+)?|[!?.,;:]")   # approximates the C tokenizer
def load(f):
    y, x = [], []
    for l in open(f'{D}/{f}'):
        a, b = l.rstrip('\n').split('\t', 1); y.append(int(a))
        x.append(tok.findall(re.sub(r'<[^>]*>', ' ', b.lower())))
    return x, np.array(y)
tr, ytr = load('train.tsv'); va, yva = load('val.tsv'); te, yte = load('test_clean.tsv')
def view(docs, T, cap):
    return [[w if (not cap or w in vset) else '[unk]' for w in (d[:T] if T else d)] for d in docs]
def run(name, T, cap, bigrams=False, chars=False):
    t = time.time(); a, b, c = view(tr, T, cap), view(va, T, cap), view(te, T, cap)
    an = (lambda d: d + [x + ' ' + y for x, y in zip(d, d[1:])]) if bigrams else (lambda d: d)
    v = TfidfVectorizer(analyzer=an, sublinear_tf=True, min_df=2)
    A, B, C = [v.fit_transform(a)], [v.transform(b)], [v.transform(c)]
    if chars:
        j = lambda ds: [' '.join(d) for d in ds]
        cv = TfidfVectorizer(analyzer='char_wb', ngram_range=(3, 6), sublinear_tf=True, min_df=3, max_features=300000)
        A.append(cv.fit_transform(j(a))); B.append(cv.transform(j(b))); C.append(cv.transform(j(c)))
    A, B, C = (sp.hstack(z).tocsr() for z in (A, B, C))
    m = LogisticRegression(C=10, max_iter=3000).fit(A, ytr)
    print(f'{name:<44} val={m.score(B, yva):.4f}  test={m.score(C, yte):.4f}  ({time.time()-t:.0f}s)', flush=True)
if which == 'a':
    run('word uni, full vocab, full text', 0, False)
    run('word uni, our vocab, full text', 0, True)
    run('word uni, our vocab, first 512 tokens', 512, True)
    run('word uni, our vocab, first 128 tokens', 128, True)
else:
    run('word uni+bigram, our vocab, 512 tokens', 512, True, bigrams=True)
    run('word uni + char 3-6, our vocab, 512 tokens', 512, True, chars=True)
    run('word uni+bi + char 3-6, full vocab, 512', 512, False, bigrams=True, chars=True)
