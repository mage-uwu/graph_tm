#!/usr/bin/env bash
# Bitwise-equivalence gate. Any change to src/logic_text.c must pass this unless the
# change is an intentional numerics change (then re-baseline and say so in RESULTS.md).
# Compares: reference serial build vs src build at 1 thread and at N threads,
# on supervised training AND MLM pretraining, at batch 64 (4 lane chunks).
set -euo pipefail
REPO=$(cd "$(dirname "$0")/.." && pwd); cd "$REPO"
N=${THREADS:-4}; D=data/imdb
[ -f $D/train.tsv ] || { echo "run: make data"; exit 1; }
[ -f $D/vocab.txt ] || bin/lt vocab --data $D/train.tsv --format tsv --out $D/vocab.txt --seq 256
T=$(mktemp -d)
C="--data $D/train.tsv --format tsv --vocab $D/vocab.txt --batch 64 --steps 200 --seed 7"
bin/lt_ref train $C --save $T/r.ltc --stop-after 8 --eval-every 8 2>/dev/null
bin/lt train --threads 1  $C --save $T/a.ltc --stop-after 8 --eval-every 8 2>/dev/null
bin/lt train --threads $N $C --save $T/b.ltc --stop-after 8 --eval-every 8 2>/dev/null
bin/lt_ref pretrain $C --save $T/rp.ltc --stop-after 4 --eval-every 4 2>/dev/null
bin/lt pretrain --threads 1  $C --save $T/ap.ltc --stop-after 4 --eval-every 4 2>/dev/null
bin/lt pretrain --threads $N $C --save $T/bp.ltc --stop-after 4 --eval-every 4 2>/dev/null
ok=1
cmp -s $T/r.ltc $T/a.ltc && cmp -s $T/r.ltc $T/b.ltc && echo "supervised: ref == src@1 == src@$N  PASS" || { echo "supervised: MISMATCH"; ok=0; }
cmp -s $T/rp.ltc $T/ap.ltc && cmp -s $T/rp.ltc $T/bp.ltc && echo "MLM:        ref == src@1 == src@$N  PASS" || { echo "MLM: MISMATCH"; ok=0; }
rm -rf $T; [ $ok = 1 ]
