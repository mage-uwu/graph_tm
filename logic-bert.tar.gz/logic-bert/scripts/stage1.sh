#!/usr/bin/env bash
# stage1.sh -- Logic-BERT sanity check.
#   MLM-pretrain on WikiText-2, fine-tune on SST-2, compare against training from scratch.
# Needs: gcc with OpenMP, curl, awk. python3 + scikit-learn optional (baselines).
# Run from anywhere: scripts/stage1.sh. Work dir: runs/stage1 (override WORKDIR).
# Deliverable: runs/stage1/stage1_summary.txt. Gates G1-G4 are defined in TASKS.md.
# Knobs (env): THREADS, PT_TOKENS, PT_BATCH, MLM_CAP, FT_STEPS, SEEDS
set -euo pipefail
REPO=$(cd "$(dirname "$0")/.." && pwd)
W=${WORKDIR:-$REPO/runs/stage1}; mkdir -p "$W"; cd "$W"
T=${THREADS:-$(nproc)}
PT_TOKENS=${PT_TOKENS:-64000000}      # MLM training tokens (~30 passes over WikiText-2)
PT_BATCH=${PT_BATCH:-256}
MLM_CAP=${MLM_CAP:-1024}              # masked targets per step (caps positions, not vocab)
FT_STEPS=${FT_STEPS:-2000}            # SST-2 fine-tune steps at batch 32 (~9 epochs)
SEEDS=${SEEDS:-"17 23"}
PT_STEPS=$(( PT_TOKENS / (PT_BATCH*128) )); [ "$PT_STEPS" -ge 10 ] || PT_STEPS=10
EV=$(( PT_STEPS/10 )); [ "$EV" -ge 1 ] || EV=1
S=stage1_summary.txt; : > $S
log(){ echo "$*" | tee -a $S; }

log "== machine =="
log "cores=$(nproc) threads=$T model=$(lscpu | sed -n 's/^Model name: *//p' | head -1)"
log "avx512=$(grep -c -m1 avx512f /proc/cpuinfo || true) mem=$(free -g | awk '/Mem:/{print $2}')GB"

log "== build + correctness =="
gcc -O3 -march=native -std=c11 -fopenmp -Wno-unknown-pragmas "$REPO/src/logic_text.c" -lm -o lt
OMP_NUM_THREADS=$T ./lt selftest | tail -1 | tee -a $S

[ -f wiki2.txt ] || curl -sL -o wiki2.txt https://raw.githubusercontent.com/pytorch/examples/main/word_language_model/data/wikitext-2/train.txt
[ -f sst_train.raw ] || curl -sL -o sst_train.raw https://raw.githubusercontent.com/clairett/pytorch-sentiment-classification/master/data/SST2/train.tsv
[ -f sst_dev.raw ] || curl -sL -o sst_dev.raw https://raw.githubusercontent.com/clairett/pytorch-sentiment-classification/master/data/SST2/dev.tsv
awk -F'\t' 'NF==2{print $2"\t"$1}' sst_train.raw > sst_train.tsv
awk -F'\t' 'NF==2{print $2"\t"$1}' sst_dev.raw > sst_dev.tsv
# ~110 whitespace tokens per line so documents fit the 128-token window
awk '{for(i=1;i<=NF;i++){b=b" "$i;n++;if(n==110){print b;b="";n=0}}}END{if(n)print b}' wiki2.txt > chunks.txt
L=$(wc -l < chunks.txt); V=$(( L/50 ))
head -n $(( L-V )) chunks.txt > wiki_train.txt; tail -n $V chunks.txt > wiki_val.txt
cut -f2 sst_train.tsv | cat wiki_train.txt - > vocab_src.txt
./lt vocab --data vocab_src.txt --format text --out vocab.txt --vocab-size 8192 --seq 128 2>&1 | tee -a $S
log "data: wiki_train=$(( L-V )) chunks, wiki_val=$V chunks, sst_train=$(wc -l < sst_train.tsv), sst_dev=$(wc -l < sst_dev.tsv)"

# Bitwise determinism across thread counts (supervised + MLM).
C="--data sst_train.tsv --format tsv --vocab vocab.txt --kernel 5 --seq 64 --batch 64 --steps 100 --seed 3"
./lt train --threads 1  $C --save d1.ltc --stop-after 5 --eval-every 5 2>/dev/null
./lt train --threads $T $C --save dT.ltc --stop-after 5 --eval-every 5 2>/dev/null
M="--data wiki_train.txt --format text --vocab vocab.txt --kernel 5 --batch 64 --steps 100 --seed 3 --mlm-targets 256"
./lt pretrain --threads 1  $M --save m1.ltc --stop-after 3 --eval-every 3 2>/dev/null
./lt pretrain --threads $T $M --save mT.ltc --stop-after 3 --eval-every 3 2>/dev/null
if cmp -s d1.ltc dT.ltc && cmp -s m1.ltc mT.ltc; then log "determinism: 1 vs $T threads BITWISE IDENTICAL"; else log "determinism: MISMATCH (stop and report)"; exit 1; fi
rm -f d1.ltc dT.ltc m1.ltc mT.ltc

log "== thread scaling (MLM step, batch $((16*T)), cap $MLM_CAP) =="
for th in 1 $(( T/4 )) $(( T/2 )) $T; do
  [ "$th" -ge 1 ] || continue
  rm -f sc.ltc
  sec=$(./lt pretrain --threads $th --data wiki_train.txt --format text --vocab vocab.txt --kernel 5 \
        --batch $((16*T)) --steps 1000 --stop-after 3 --eval-every 3 --mlm-targets $MLM_CAP --save sc.ltc 2>&1 \
        | grep -o '"compute_seconds":[0-9.]*' | cut -d: -f2)
  log "threads=$th  ms/step=$(awk -v s=$sec 'BEGIN{printf "%.0f", s/3*1000}')  tokens/s=$(awk -v s=$sec -v b=$((16*T)) 'BEGIN{printf "%.0f", 3*b*128/s}')"
done; rm -f sc.ltc

log "== MLM pretrain: $PT_STEPS steps x batch $PT_BATCH x 128 = $((PT_STEPS*PT_BATCH*128)) tokens =="
t0=$(date +%s)
./lt pretrain --threads $T --data wiki_train.txt --val wiki_val.txt --format text --vocab vocab.txt \
   --kernel 5 --seq 128 --batch $PT_BATCH --steps $PT_STEPS --mlm-targets $MLM_CAP \
   --eval-every $EV --seed 17 --save pt.ltc 2> pt.log
grep -o '"step":[0-9]*\|"val_mlm_ce":[0-9.]*' pt.log | paste - - | tee -a $S
log "pretrain wall seconds: $(( $(date +%s)-t0 ))"
if command -v python3 >/dev/null; then python3 - <<'PY' | tee -a $S
import re,math,collections
voc=[l.rstrip('\n') for l in open('vocab.txt')]; idx={w:i for i,w in enumerate(voc)}
tok=re.compile(r"[a-z0-9]+(?:'[a-z]+)?|[!?.,;:]")
def ids(f):
    for line in open(f):
        for w in tok.findall(re.sub(r'<[^>]*>',' ',line.lower()))[:128]:
            yield idx.get(w,2)
c=collections.Counter(i for i in ids('wiki_train.txt') if i>=3)
tot=sum(c.values()); val=[i for i in ids('wiki_val.txt') if i>=3]
ce=-sum(math.log((c[i]+1)/(tot+len(voc))) for i in val)/len(val)
print(f"unigram baseline CE on wiki_val (approx tokenizer): {ce:.3f} nats; uniform = {math.log(len(voc)-3):.3f}")
PY
fi

log "== SST-2 fine-tune: $FT_STEPS steps, batch 32, seq 64, final-step dev accuracy (no selection) =="
ft(){ # name seed extra...
  n=$1; s=$2; shift 2
  ./lt train --threads $T --data sst_train.tsv --val sst_dev.tsv --format tsv --seq 64 --batch 32 \
     --steps $FT_STEPS --eval-every 250 --seed $s --save $n.ltc --export $n.lth "$@" 2> $n.log
  acc=$(./lt eval --load $n.lth --data sst_dev.tsv --format tsv --seq 64 --batch 64 | grep -o '0\.[0-9]*')
  best=$(grep -o '"val_hard_accuracy":[0-9.]*' $n.log | cut -d: -f2 | sort -n | tail -1)
  log "$n  final_dev=$acc  (best_seen=$best)"
}
for s in $SEEDS; do
  ft scratch_s$s     $s --vocab vocab.txt --kernel 5
  ft pretrain_lr025_s$s $s --load pt.ltc
  ft pretrain_lr005_s$s $s --load pt.ltc --lr .005
done

if python3 -c "import sklearn" 2>/dev/null; then python3 - <<'PY' | tee -a $S
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
def load(f):
    y,x=[],[]
    for l in open(f):
        a,b=l.rstrip('\n').split('\t',1); y.append(int(a)); x.append(b)
    return x,y
xt,yt=load('sst_train.tsv'); xd,yd=load('sst_dev.tsv')
for ng in [(1,1),(1,2)]:
    v=TfidfVectorizer(ngram_range=ng,sublinear_tf=True); A=v.fit_transform(xt)
    m=LogisticRegression(C=10,max_iter=3000).fit(A,yt)
    print(f"BoW baseline tfidf{ng}+LR: dev={m.score(v.transform(xd),yd):.4f}")
PY
fi
log "== done =="
