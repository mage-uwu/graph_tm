#!/usr/bin/env python3
"""Reproduce the exact IMDB splits used for every number in RESULTS.md.
Outputs (label<TAB>text, 0=neg 1=pos) in data/imdb/:
  train.tsv       22,500  official 25k train minus val (shuffled, random.Random(0))
  val.tsv          2,500  held out from official train
  test_clean.tsv  24,681  full 50k corpus minus anything in train/val, deduplicated
WARNING: the laxmimerit mirror's test.xlsx is a copy of TRAIN reviews (25,000/25,000
overlap). It is never downloaded or used here. Needs pandas + openpyxl."""
import os, re, random, subprocess, sys
import pandas as pd
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'imdb')
os.makedirs(D, exist_ok=True)
SRC = {
 'train.xlsx': 'https://raw.githubusercontent.com/laxmimerit/IMDB-Movie-Reviews-Large-Dataset-50k/master/train.xlsx',
 'imdb50k.csv': 'https://raw.githubusercontent.com/Ankit152/IMDB-sentiment-analysis/master/IMDB-Dataset.csv',
}
for f, u in SRC.items():
    p = os.path.join(D, f)
    if not os.path.exists(p):
        print('downloading', f, file=sys.stderr)
        subprocess.check_call(['curl', '-sSL', '-o', p, u])
clean = lambda s: re.sub(r'[\t\r\n]+', ' ', str(s))
tr = pd.read_excel(os.path.join(D, 'train.xlsx'))
rows = [(1 if y == 'pos' else 0, clean(x)) for x, y in zip(tr.Reviews, tr.Sentiment)]
random.Random(0).shuffle(rows)
val, train = rows[:2500], rows[2500:]
def w(name, r):
    with open(os.path.join(D, name), 'w') as f:
        f.write(''.join(f'{a}\t{b}\n' for a, b in r))
w('train.tsv', train); w('val.tsv', val)
seen = set(b for _, b in train + val)
full = pd.read_csv(os.path.join(D, 'imdb50k.csv'))
out, s2 = [], set()
for x, y in zip(full.review, full.sentiment):
    b = clean(x)
    if b not in seen and b not in s2:
        out.append((1 if y == 'positive' else 0, b)); s2.add(b)
w('test_clean.tsv', out)
print(f'train={len(train)} val={len(val)} test_clean={len(out)} -> {D}')
