# RESULTS.md — everything measured so far

All IMDB numbers: splits from `scripts/prep_imdb.py` (train 22,500 / val 2,500 / test_clean
24,681), vocab 8,192 built from train, defaults unless stated: bits 64, width 128, blocks 8,
tree depth 3, kernel 3, votes 128, batch 16, seq 128 in training, lr .025 cosine, sigmoid
estimator. "@128/@512" = hard accuracy evaluated with that many tokens. "Fit" = hard
accuracy on 2,500 *training* reviews (measures fitting, not generalization).

## 1. Baseline
| Run | val@128 | val@512 | test_clean@128 | test_clean@512 | Fit |
|---|---|---|---|---|---|
| default, 6000 steps, seed 17 (`models/imdb_baseline_k3.lth`) | 82.48 | 86.00 | 80.13 | 83.66 | 90.5 |

Deployed: 237 KB, 8,960 gate truth tables. Bench: ~4,400 reviews/s (batch 64, seq 512, 1 core,
excludes tokenization). Hard-vs-soft gap measured ≤1.3 pts (hardening is not the bottleneck).
Negation fails: "Not bad at all." → negative.

## 2. Scaling experiments (none of these beat the baseline except kernel 5)
| Run | Steps | val@128 | val@512 | Fit | Verdict |
|---|---|---|---|---|---|
| seed 101 (baseline for data/width rows) | 3000 | 80.84 | 84.96 | 86.1 | — |
| 25% data, seed 101 | 3000 | 80.56 | 83.68 | 95.8 | memorizes |
| width 256, seed 101 | 3000 | 81.52 | 85.44 | 86.6 | no gain, 2.5× cost |
| 12k steps, seed 101 | 12000 | 81.80 | 84.72 | 94.2 | overfits vs 6k |
| **kernel 5, seed 17** (`models/imdb_kernel5.lth`) | 6000 | 82.52 | **86.84** | 90.3 | **best single model** |
| 16 blocks, seed 17 | 6000 | 81.76 | 83.60 | 91.0 | worse, esp. long seq |
| 16 blocks, seed 17 | 12000 | 80.1 @ step 7000 (parked) | — | — | flat 79.5–80.2 steps 3k–7k |
| vocab 2,048 | 2250 (partial) | ~76.8 | 79.4 | — | worse; rare words matter |
| fine-tune baseline at seq 512, lr .01 | +2000 | — | 85.5 (peak 86.2) | — | no gain vs eval@512 |
| ensemble: baseline + vocab2k + ft512 (vote sum) | — | — | 87.0 | — | diversity helps |

Interpretation so far: 3k→6k steps helped (+1.7 @128); 6k→12k overfits; width and depth
(blocks) do not help; widening each tree's reachable inputs (kernel 5) is the only
architectural win. Working hypothesis: fixed random wiring limits what extra layers/width
can use. Data only helps when each example is seen ≥ ~4 times.

## 3. Performance engineering (all bitwise-identical to reference)
| Build | ms/step b16 | ms/step b64 | Notes |
|---|---|---|---|
| reference (serial) | 233 | 893 | fwd 27%, bwd 70%, adam 3% |
| lane-major (src) | 104 | 443 | fwd 3.5×, bwd 1.95× faster |
| + deterministic OpenMP | same on 1 core | — | ref == src@1 == src@4, sup + MLM |
Microbenchmark (tools/micro.c) of backward inner math: scalar fp32 24.4 Mtrees/s, scalar fp16
19.5 (0.80×), fp32 16-lane 49.5 (2.03×). MLM step: 413 ms uncapped, 171 ms `--mlm-targets 64`.

## 4. External references
- BERT-Tiny (L=2, H=128, 4.4M params, ~3.9M of them word embeddings), GLUE **test**:
  CoLA 0.0, SST-2 83.2, MRPC 81.1/71.1, STS-B 74.3/73.6, QQP 62.2/83.4, MNLI-m 70.2,
  MNLI-mm 70.3, QNLI 81.5, RTE 57.2 (google-research/bert README). Community fine-tunes of
  the same checkpoint: ~80–84% SST-2 dev.
- Fine-tuned BERT-base on IMDB: ~93–95% (literature, not measured here).

## 5. Lexical ablation — TF-IDF + logistic regression, our splits and tokenizer
| Input | val | test_clean |
|---|---|---|
| word uni, full vocab, full text | 90.00 | 88.59 |
| word uni, our 8k vocab, full text | 88.92 | 87.90 |
| word uni, our vocab, first 512 tokens | 88.84 | 87.57 |
| word uni, our vocab, first 128 tokens | 84.16 | 81.95 |
| word uni+bigram, our vocab, 512 | **90.24** | **90.37** |
| word uni + char 3–6-grams, our vocab, 512 | 88.44 | 87.29 |
| uni+bi+char, full vocab, 512 | 90.84 | 89.81 |
| (sklearn default uni+bigram, full text, 200k feats) | 90.28 | 90.63 |
Facts: median review 194 tokens, 90th pct 508, 9.8% > 512. UNK rate with 8k vocab: 6.10%.
Findings: bigrams are the big lexical win (+1.4 val / +2.8 test); vocab cap costs ~0.7–1.1;
char n-grams *hurt* on IMDB. **At identical information (our vocab, 512 tokens) a linear
unigram model beats the logic net 88.8 vs 86.8 val** → readout/aggregation is also a
bottleneck, not only features.

## 6. Stage 1 smoke test (tiny budgets, 1 core — plumbing only, not a result)
WikiText-2 (2.0M words → 18,281 train / 373 val chunks of 110 words), SST-2 sentence-level
(6,920 train / 872 dev). Unigram CE baseline on wiki val: **6.393 nats** (uniform 9.011).
BoW on SST-2 dev: tfidf uni 79.01, uni+bi 80.16. Real Stage 1 run: pending on rented box.
