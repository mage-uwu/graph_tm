"""Assemble fastlogic.c: ONE self-contained C file (training, pretraining, adaptation, fast inference, compiled
inference, checks) from the verified pieces in this directory, with the best-recipe defaults.

  logic_text.c  (make_source.py: logic-bert + transfer, global, hard, fasttrain patches)  -> training engine
  fastlae.c     (bit-sliced inference interpreter + model -> C compiler)                  -> fast inference
  + hardcheck (training forward == deployed network), revive (reset dead channels), one main()
  + defaults = the best recipe (see the header written below)

usage: python3 build_fastlogic.py   (writes fastlogic.c next to this file; the result is committed)
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
HEADER = open(os.path.join(HERE, "fastlogic_header.txt")).read()


def edit(s, a, b, count=1):
    if s.count(a) != count:
        sys.exit(f"build_fastlogic: anchor found {s.count(a)}x (want {count}): {a[:80]!r}")
    return s.replace(a, b)


def engine():
    s = open(os.path.join(HERE, "logic_text.c")).read()
    s = s[s.index("#define _POSIX_C_SOURCE"):]  # drop the generated/provenance comments (HEADER replaces them)
    # best-recipe architecture and optimisation defaults (all overridable by flags)
    s = edit(s, "    Config c={8192,64,128,8,3,3,8,128,0,0,128,16,1000,0,0,\n",
             "    Config c={30522,128,1024,16,3,5,4,128,0,0,64,32,1000,0,512,  /* best recipe: see the header */\n")
    # hard forward (straight-through) for train AND pretrain; --soft-forward opts out
    s = edit(s, "        g_hard_fwd=g_fwd_opt>=0?g_fwd_opt:!stage;\n", "        g_hard_fwd=g_fwd_opt>=0?g_fwd_opt:1;\n")
    s = edit(s, "static int g_hard_fwd=0,g_fwd_opt=-1;  /* straight-through (hard_patch.py); g_fwd_opt -1 = train: hard, pretrain: soft */",
             "static int g_hard_fwd=0,g_fwd_opt=-1;  /* hard (straight-through) forward; g_fwd_opt: -1 default (hard), 0 --soft-forward, 1 --hard-forward */")
    # adaptation keeps the checkpoint's code temperature by default (--reset-temperature for the old 1.0 -> 0.2 re-anneal)
    s = edit(s, '        if(!strcmp(key,"--keep-temperature")){o.keep_temp=1;continue;}\n',
             '        if(!strcmp(key,"--keep-temperature")){o.keep_temp=1;continue;}\n'
             '        if(!strcmp(key,"--reset-temperature")){o.keep_temp=0;continue;}\n')
    s = edit(s, "    Options o={0};o.c=defaults();o.threads=thread_count();",
             "    Options o={0};o.c=defaults();o.keep_temp=1;o.threads=thread_count();")
    # pretraining batch 64 unless --batch is given (supervised default stays 32)
    s = edit(s, "        }else{n=net_new(o.c,1,1,o.seed);n->c.stage=stage;}",
             "        }else{if(stage && !(o.changed&(UINT64_C(1)<<11)))o.c.batch=64;n=net_new(o.c,1,1,o.seed);n->c.stage=stage;}")
    # the engine's main becomes lt_main (the one main() is at the end of the file)
    s = edit(s, "#ifndef LOGIC_NO_MAIN\nint main(int argc,char **argv) {\n"
                "    if(!getenv(\"OMP_WAIT_POLICY\")){setenv(\"OMP_WAIT_POLICY\",\"passive\",1);execv(\"/proc/self/exe\",argv);}  /* before OpenMP starts */\n",
             "static int lt_main(int argc,char **argv) {\n")
    assert s.rstrip().endswith("#endif")
    s = s.rstrip()[:-len("#endif")] + "\n"
    # help text
    a = s.index("static void usage(void) {")
    b = s.index("}\n", a) + 2
    s = s[:a] + "static void usage(void) {\n    fputs(USAGE,stdout);\n}\n" + s[b:]
    return s


def fast():
    s = open(os.path.join(HERE, "fastlae.c")).read()
    s = s[s.index('#include "logic_text.c"') + len('#include "logic_text.c"'):]
    s = edit(s, "#ifdef FASTLAE_GEN\n", "#ifdef GEN_INC\n")
    s = edit(s, "int main(int argc, char **argv) {\n", "static int fast_main(int argc, char **argv) {\n")
    s = edit(s, 'die("usage: fastlae verify|predict|bench MODEL.lth DATA.ids SEQ [--threads N] [--lanes L] [--batch B] [--repeats R]");',
             'die("usage: fastlogic predict|verify|bench|gen MODEL.lth DATA.ids SEQ [...] (fastlogic help)");')
    s = edit(s, 'int threads = opt_int(argc, argv, "--threads", 1), lanes = opt_int(argc, argv, "--lanes", 1);',
             'int threads = opt_int(argc, argv, "--threads", thread_count()), lanes = opt_int(argc, argv, "--lanes", 8);')
    s = edit(s, '/* fastgen.c defines FASTLAE_GEN and includes the network compiled to C (fastlae gen): all blocks\n'
                ' * as straight-line word operations for T <= 64. Without it the interpreter runs every layer. */\n',
             '/* Built with -DGEN_INC=\'"model.inc"\' (from `fastlogic gen`), the blocks of that one model run as straight-line\n'
             ' * word operations for T <= 64 (see the end of the file). Without it the interpreter runs every layer. */\n')
    return s


TAIL = r'''
/* =====================================================================================================
 * checks and tools
 * ===================================================================================================== */
/* hardcheck: the training forward pass (hard, what train/pretrain optimize) must compute exactly the deployed
 * network: for every record, the class-vote difference from supervised() == hard_predict's integer votes. */
static int hardcheck_main(int argc,char **argv){
    if(argc<5)die("usage: fastlogic hardcheck MODEL.ltc DATA.ids SEQ");
    int T=(int)parse_long(argv[4],1,65536),B=32;threads_set(thread_count());
    Net *n=load_net(argv[2]);n->c.stage=0;g_hard_fwd=1;refresh(n);
    Data d=data_load(argv[3],"ids",&n->vocab,n->c.vocab,T);
    Hard *h=harden(n);HWork *hw=hwork_new(h,B,T);Work *w=work_new(n,B,T);
    int bad=0,N=0,O=2*n->c.votes;
    for(int i=0;i+B<=d.n;i+=B){
        memcpy(w->ids,d.x+(size_t)i*T,(size_t)B*T*4);
        for(int b=0;b<B;b++)w->labels[b]=d.y[i+b]<0?0:d.y[i+b];
        supervised(n,w,0,NULL);hard_predict(h,hw,d.x+(size_t)i*T);
        for(int b=0;b<B;b++){
            double s[2]={0,0};for(int u=0;u<w->U;u++)for(int o=0;o<O;o++)s[o/n->c.votes]+=w->head[((size_t)u*O+o)*B+b];
            bad+=llround(s[1]-s[0])!=(long long)(hw->scores[2*b+1]-hw->scores[2*b]);N++;
        }
    }
    printf("{\"records\":%d,\"vote_mismatches\":%d}\n",N,bad);
    return bad!=0;
}
/* revive: gates whose output channel is constant (hard forward, over the valid positions of DATA) are reset to
 * the scratch pass-through init (+-3). Dead, saturated channels are why masked-word pretraining did not transfer. */
static int revive_main(int argc,char **argv){
    if(argc<6)die("usage: fastlogic revive MODEL.ltc DATA.ids SEQ OUT.ltc");
    int T=(int)parse_long(argv[4],1,65536),B=64;threads_set(thread_count());
    Net *n=load_net(argv[2]);g_hard_fwd=1;refresh(n);int K=n->c.blocks,W=n->c.width;
    Data d=data_load(argv[3],"ids",&n->vocab,n->c.vocab,T);Work *w=work_new(n,B,T);
    uint8_t *s0=alloc((size_t)K*W,1),*s1=alloc((size_t)K*W,1);
    for(int i=0;i<d.n;i+=B){
        int take=d.n-i<B?d.n-i:B;memset(w->ids,0,(size_t)B*T*4);
        for(int b=0;b<take;b++)memcpy(w->ids+(size_t)b*T,d.x+(size_t)(i+b)*T,T*4);
        encode(n,w);
        #pragma omp parallel for schedule(static)
        for(int li=0;li<K;li++)for(int c=0;c<W;c++)for(int t=0;t<T;t++)for(int b=0;b<take;b++)
            if(w->valid[(size_t)b*T+t]){if(w->a[li+1][((size_t)t*W+c)*B+b]>.5f)s1[li*W+c]=1;else s0[li*W+c]=1;}
    }
    int tot=0;
    for(int li=0;li<K;li++){
        Layer *l=n->l+li;int dead=0;
        for(int o=0;o<W;o++)if(!(s0[li*W+o]&&s1[li*W+o])){dead++;for(int k=0;k<l->N*4;k++)l->p.z[(size_t)o*l->N*4+k]=(k%4)<2?-3.f:3.f;}
        fprintf(stderr,"block %d: %d/%d dead\n",li,dead,W);tot+=dead;
    }
    save_net(n,argv[5]);printf("{\"reset_channels\":%d,\"of\":%d}\n",tot,K*W);return 0;
}

/* =====================================================================================================
 * main
 * ===================================================================================================== */
int main(int argc,char **argv){
    if(!getenv("OMP_WAIT_POLICY")){setenv("OMP_WAIT_POLICY","passive",1);execv("/proc/self/exe",argv);}  /* before OpenMP starts */
    if(sizeof(float)!=4 || FLT_RADIX!=2 || FLT_MANT_DIG!=24)die("requires IEEE-754 binary32 floats");
    if(argc<2 || !strcmp(argv[1],"help") || !strcmp(argv[1],"--help")){usage();return 0;}
    const char *c=argv[1];
    if(!strcmp(c,"predict")||!strcmp(c,"verify")||!strcmp(c,"bench")||!strcmp(c,"gen"))return fast_main(argc,argv);
    if(!strcmp(c,"hardcheck"))return hardcheck_main(argc,argv);
    if(!strcmp(c,"revive"))return revive_main(argc,argv);
    if(!strcmp(c,"predict-ref"))argv[1]=(char*)"predict";
    else if(!strcmp(c,"bench-ref"))argv[1]=(char*)"bench";
    return lt_main(argc,argv);
}

/* =====================================================================================================
 * compiled model (optional): gcc ... -DGEN_INC='"model.inc"' fastlogic.c   (model.inc from `fastlogic gen`)
 * ===================================================================================================== */
#ifdef GEN_INC
#define V v1
#define GEN_L(n) n##_1
#include GEN_INC
#undef V
#undef GEN_L
#define V v2
#define GEN_L(n) n##_2
#include GEN_INC
#undef V
#undef GEN_L
#define V v4
#define GEN_L(n) n##_4
#include GEN_INC
#undef V
#undef GEN_L
#define V v8
#define GEN_L(n) n##_8
#include GEN_INC
#undef V
#undef GEN_L
static void gen_blocks_1(v1 *a, v1 *b, const v1 *valid) { blocks_1(a, b, valid); }
static void gen_blocks_2(v2 *a, v2 *b, const v2 *valid) { blocks_2(a, b, valid); }
static void gen_blocks_4(v4 *a, v4 *b, const v4 *valid) { blocks_4(a, b, valid); }
static void gen_blocks_8(v8 *a, v8 *b, const v8 *valid) { blocks_8(a, b, valid); }
static int gen_nwords(void) { return GEN_NWORDS; }
#endif
'''

SECTION = "\n/* =====================================================================================================\n * {}\n * ===================================================================================================== */\n"


def main():
    eng = engine()
    usage = HEADER[HEADER.index("USAGE_BEGIN") + len("USAGE_BEGIN"):HEADER.index("USAGE_END")].strip("\n")
    head = HEADER[:HEADER.index("USAGE_BEGIN")].rstrip() + "\n"
    cstr = "".join('"' + line.replace("\\", "\\\\").replace('"', '\\"') + '\\n"\n' for line in usage.split("\n"))
    eng = edit(eng, "static void usage(void) {\n", "static const char *USAGE=\n" + cstr + ";\nstatic void usage(void) {\n")
    out = head + SECTION.format("training engine: codes, gate trees, objectives, Adam, checkpoints, hardened network") + eng + \
        SECTION.format("fast inference: bit-sliced interpreter (bit t = token position t), lanes, compiler to C") + fast() + TAIL
    open(os.path.join(HERE, "fastlogic.c"), "w").write(out)
    print("wrote", os.path.join(HERE, "fastlogic.c"), f"({out.count(chr(10))} lines)")


if __name__ == "__main__":
    main()
